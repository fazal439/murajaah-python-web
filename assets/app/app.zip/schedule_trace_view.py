import csv
from pathlib import Path

import flet as ft


BASE = Path(__file__).resolve().parent
ACTIVE_COLOR = "#63E6BE"
INACTIVE_COLOR = "#8FA3B8"
CARD_COLOR = "#10243E"


def build_schedule_trace_card():
    try:
        with (BASE / "repeated_multi_ayah_trace.csv").open(
            newline="", encoding="utf-8-sig"
        ) as file:
            rows = list(csv.DictReader(file))

        learner_ids = {row["learner_id"] for row in rows}
        if len(learner_ids) != 1:
            raise ValueError("One example learner is required.")

        learner_id = next(iter(learner_ids))
        groups = {}

        for row in rows:
            key = (int(row["day"]), row["strategy"])
            groups.setdefault(key, []).append(row)

        days = sorted({int(row["day"]) for row in rows})
        if not days:
            raise ValueError("No recorded revision days.")

        for day in days:
            for strategy in ("round_robin", "ai_risk"):
                selected = groups.get((day, strategy), [])
                if (
                    len(selected) != 3
                    or len({
                        row["simulated_ayah_id"] for row in selected
                    }) != 3
                ):
                    raise ValueError("Incomplete daily schedule.")

        state = {"index": 0}
        day_label = ft.Text(
            size=16,
            weight=ft.FontWeight.BOLD,
            color=ACTIVE_COLOR,
        )
        simple_table = ft.Column(spacing=8)
        ai_table = ft.Column(spacing=8)
        explanation = ft.Text(size=12, color=INACTIVE_COLOR)

        def table_row(values, header=False):
            return ft.Row(
                [
                    ft.Container(
                        expand=1,
                        content=ft.Text(
                            value,
                            size=12,
                            color=(
                                INACTIVE_COLOR
                                if header else ACTIVE_COLOR
                            ),
                        ),
                    )
                    for value in values
                ],
                spacing=8,
            )

        def make_table(selected):
            controls = [
                table_row(
                    [
                        "Simulated ayah",
                        "Days since review",
                        "Earlier reviews",
                        "Predicted risk",
                        "Review result",
                    ],
                    header=True,
                )
            ]

            for row in selected:
                raw_risk = row["predicted_failure_risk"]
                risk = (
                    f"{float(raw_risk):.1%}"
                    if raw_risk.strip() else "Not used"
                )
                outcome = (
                    "Success"
                    if row["simulated_success"] == "1"
                    else "Failure"
                )

                controls.append(
                    table_row([
                        row["simulated_ayah_id"],
                        row["gap_days"],
                        row["previous_attempt_count"],
                        risk,
                        outcome,
                    ])
                )

            return controls

        def render_day():
            day = days[state["index"]]
            day_label.value = f"Day {day} of {days[-1]}"

            simple_table.controls = make_table(
                groups[(day, "round_robin")]
            )
            selected_ai = groups[(day, "ai_risk")]
            ai_table.controls = make_table(selected_ai)

            reasons = {
                row["selection_reason"] for row in selected_ai
            }
            if "fallback_oldest_first" in reasons:
                explanation.value = (
                    "AI used the oldest-first fallback because "
                    "some inputs were outside its training ranges."
                )
            else:
                explanation.value = (
                    "AI selected the three ayahs with the highest "
                    "predicted failure risk. Ties favour older reviews "
                    "and then the smaller simulated ayah ID."
                )

            previous_button.disabled = state["index"] == 0
            next_button.disabled = state["index"] == len(days) - 1

        def previous_day(event):
            state["index"] = max(0, state["index"] - 1)
            render_day()
            card.update()

        def next_day(event):
            state["index"] = min(
                len(days) - 1, state["index"] + 1
            )
            render_day()
            card.update()

        previous_button = ft.TextButton(
            content="Previous day",
            on_click=previous_day,
        )
        next_button = ft.TextButton(
            content="Next day",
            on_click=next_day,
        )

        card = ft.Container(
            padding=18,
            bgcolor=CARD_COLOR,
            border_radius=20,
            content=ft.Column(
                [
                    ft.Text(
                        "Example Learner Schedule",
                        size=22,
                        weight=ft.FontWeight.BOLD,
                        color=ACTIVE_COLOR,
                    ),
                    ft.Text(
                        f"Saved simulation example: {learner_id}",
                        size=12,
                        color=INACTIVE_COLOR,
                    ),
                    ft.Row(
                        [
                            previous_button,
                            day_label,
                            next_button,
                        ],
                        spacing=12,
                        wrap=True,
                    ),
                    ft.Text(
                        "Simple schedule: fixed rotation",
                        size=15,
                        color=ACTIVE_COLOR,
                    ),
                    simple_table,
                    ft.Divider(),
                    ft.Text(
                        "AI schedule",
                        size=15,
                        color=ACTIVE_COLOR,
                    ),
                    ai_table,
                    explanation,
                    ft.Divider(),
                    ft.Text(
                        "Predicted risk and earlier reviews are recorded "
                        "before revision. The result is recorded afterwards.",
                        size=12,
                        color=INACTIVE_COLOR,
                    ),
                    ft.Text(
                        "Each schedule has its own evolving review history. "
                        "Both use the same initial learner and item seeds.",
                        size=12,
                        color=INACTIVE_COLOR,
                    ),
                    ft.Text(
                        "Saved trace from one virtual learner · "
                        "synthetic ayah IDs · "
                        "not a recommendation for a real learner",
                        size=12,
                        color="#FFB86B",
                    ),
                ],
                spacing=12,
            ),
        )

        render_day()
        return card

    except (OSError, ValueError, KeyError, TypeError) as error:
        print("Schedule trace error:", error)
        return ft.Container(
            padding=18,
            bgcolor=CARD_COLOR,
            border_radius=20,
            content=ft.Text(
                "Example schedule unavailable.",
                color=INACTIVE_COLOR,
            ),
        )