import json
from pathlib import Path

import flet as ft


BASE = Path(__file__).resolve().parent
ACTIVE_COLOR = "#63E6BE"
INACTIVE_COLOR = "#8FA3B8"
CARD_COLOR = "#10243E"


def build_multi_ayah_card():
    try:
        report = json.loads(
            (BASE / "repeated_multi_ayah_report.json").read_text(
                encoding="utf-8"
            )
        )

        if not report["equal_revision_counts_verified"]:
            raise ValueError("Equal revision counts were not verified.")

        simple = report["summary"]["round_robin"]
        ai = report["summary"]["ai_risk"]

        difference = report["paired_differences"][
            "mean_final_recall_probability"
        ]
        value = difference["mean_ai_minus_round_robin"]
        low, high = difference["bootstrap_95_percent_interval"]

        if low > 0:
            finding = (
                "AI has higher final recall probability in this "
                "simulated setting."
            )
        elif high < 0:
            finding = (
                "AI has lower final recall probability in this "
                "simulated setting."
            )
        else:
            finding = (
                "No clear evidence of higher or lower AI final recall "
                "probability in this simulated setting. "
                "This does not establish equivalence."
            )

        def comparison_row(label, simple_value, ai_value):
            return ft.Row(
                [
                    ft.Container(
                        expand=2,
                        content=ft.Text(
                            label, size=12, color=INACTIVE_COLOR
                        ),
                    ),
                    ft.Container(
                        expand=1,
                        content=ft.Text(
                            simple_value, size=14, color=ACTIVE_COLOR
                        ),
                    ),
                    ft.Container(
                        expand=1,
                        content=ft.Text(
                            ai_value, size=14, color=ACTIVE_COLOR
                        ),
                    ),
                ],
                spacing=8,
            )

        controls = [
            ft.Text(
                "Multi-Ayah Scheduling Evaluation",
                size=22,
                weight=ft.FontWeight.BOLD,
                color=ACTIVE_COLOR,
            ),
            ft.Text(
                f'{report["runs"]} runs · '
                f'{report["virtual_learner_cases"]} virtual learner cases · '
                f'{report["simulated_ayahs_per_learner"]} '
                "simulated ayahs per learner",
                size=12,
                color=INACTIVE_COLOR,
            ),
            ft.Text(
                f'{report["daily_revision_budget"]} ayahs revised daily '
                f'for {report["revision_days"]} days. '
                f'Final assessment on day {report["total_days"]}.',
                size=12,
                color=INACTIVE_COLOR,
            ),
            ft.Text(
                "Simple: fixed rotation. AI: highest predicted failure "
                "risk, with an oldest-first fallback for inputs outside "
                "the training ranges.",
                size=12,
                color=INACTIVE_COLOR,
            ),
            comparison_row("Measure", "Simple", "AI"),
            comparison_row(
                "Mean final recall probability",
                f'{simple["mean_final_recall_probability"]:.2%}',
                f'{ai["mean_final_recall_probability"]:.2%}',
            ),
            comparison_row(
                "Final simulated success rate",
                f'{simple["final_success_rate"]:.2%}',
                f'{ai["final_success_rate"]:.2%}',
            ),
            comparison_row(
                "Mean daily recall probability",
                f'{simple["mean_daily_recall_probability"]:.2%}',
                f'{ai["mean_daily_recall_probability"]:.2%}',
            ),
            comparison_row(
                "Total revisions per learner",
                f'{simple["mean_total_revisions"]:.0f}',
                f'{ai["mean_total_revisions"]:.0f}',
            ),
            comparison_row(
                "Mean days using fallback",
                f'{simple["mean_fallback_days"]:.2f}',
                f'{ai["mean_fallback_days"]:.2f}',
            ),
            ft.Divider(),
            ft.Text(
                "Primary outcome: final recall probability",
                size=14,
                color=ACTIVE_COLOR,
            ),
            ft.Text(
                f"AI minus Simple: {value * 100:+.3f} percentage points",
                size=13,
                color=INACTIVE_COLOR,
            ),
            ft.Text(
                "95% simulation interval: "
                f"{low * 100:+.3f} to {high * 100:+.3f} "
                "percentage points",
                size=12,
                color=INACTIVE_COLOR,
            ),
            ft.Text(
                finding,
                size=13,
                color="#FFB86B",
            ),
            ft.Text(
                "The interval describes simulation randomness under "
                "one assumed memory model. It excludes uncertainty "
                "about that model and real learners.",
                size=12,
                color=INACTIVE_COLOR,
            ),
            ft.Divider(),
            ft.Text(
                "Recall probability by memory profile",
                size=14,
                color=ACTIVE_COLOR,
            ),
            ft.Text(
                "Exploratory descriptive breakdown",
                size=12,
                color=INACTIVE_COLOR,
            ),
            comparison_row("Profile", "Simple", "AI"),
        ]

        for profile in ("weak", "medium", "strong"):
            group = report["by_profile_exploratory"][profile]
            controls.append(
                comparison_row(
                    profile.title(),
                    f'{group["round_robin"]["mean_final_recall_probability"]:.2%}',
                    f'{group["ai_risk"]["mean_final_recall_probability"]:.2%}',
                )
            )

        controls.extend([
            ft.Divider(),
            ft.Text(
                "Equal revision counts verified for every learner. "
                "Review duration is not modelled.",
                size=12,
                color=INACTIVE_COLOR,
            ),
            ft.Text(
                "All simulated ayahs are assumed learned on day 0. "
                "Initial learning cost is excluded.",
                size=12,
                color=INACTIVE_COLOR,
            ),
            ft.Text(
                "Synthetic ayah IDs and assumed memory values · "
                "no measured Quran-specific difficulty · "
                "not validated on real learners",
                size=12,
                color="#FFB86B",
            ),
        ])

    except (OSError, ValueError, KeyError, TypeError) as error:
        print("Multi-ayah dashboard error:", error)
        controls = [
            ft.Text(
                "Multi-ayah evaluation results unavailable.",
                color=INACTIVE_COLOR,
            )
        ]

    return ft.Container(
        padding=18,
        bgcolor=CARD_COLOR,
        border_radius=20,
        content=ft.Column(controls, spacing=12),
    )