import re

import flet as ft

from supabase_client import sign_in_student, sign_in_user, sign_up_user


def build_auth_view(page, on_login):
    mode = {"value": "student"}
    is_signup = {"value": False}

    title = ft.Text("Student Login", size=30, weight=ft.FontWeight.BOLD)
    subtitle = ft.Text(
        "Use the Student ID and PIN given by your teacher.",
        color="#8FA3B8",
        text_align=ft.TextAlign.CENTER,
    )
    message = ft.Text("", text_align=ft.TextAlign.CENTER)

    student_id_field = ft.TextField(
        label="Student ID (for example MUR-1001)",
        prefix_icon=ft.Icons.BADGE,
        capitalization=ft.TextCapitalization.CHARACTERS,
    )
    pin_field = ft.TextField(
        label="6-digit PIN",
        prefix_icon=ft.Icons.PIN,
        password=True,
        can_reveal_password=True,
        keyboard_type=ft.KeyboardType.NUMBER,
        max_length=6,
    )
    name_field = ft.TextField(
        label="Full name",
        prefix_icon=ft.Icons.PERSON,
        visible=False,
    )
    email_field = ft.TextField(
        label="Email address",
        prefix_icon=ft.Icons.EMAIL,
        visible=False,
    )
    password_field = ft.TextField(
        label="Password",
        prefix_icon=ft.Icons.LOCK,
        password=True,
        can_reveal_password=True,
        visible=False,
    )

    async def finish_login(user):
        result = on_login(user)
        if hasattr(result, "__await__"):
            await result

    async def submit(e):
        message.value = ""
        try:
            if mode["value"] == "student":
                student_id = (student_id_field.value or "").strip().upper()
                pin = pin_field.value or ""
                if not re.fullmatch(r"MUR-\d{4,}", student_id):
                    raise ValueError("Enter a valid Student ID, for example MUR-1001.")
                if not re.fullmatch(r"\d{6}", pin):
                    raise ValueError("PIN must contain exactly 6 digits.")
                response = await sign_in_student(student_id, pin)
                if response.user:
                    await finish_login(response.user)
            elif is_signup["value"]:
                if not (name_field.value or "").strip():
                    raise ValueError("Please enter your full name.")
                response = await sign_up_user(
                    name_field.value.strip(),
                    (email_field.value or "").strip(),
                    password_field.value or "",
                )
                if response.user:
                    message.value = "Account created. You can sign in now."
                    message.color = ft.Colors.GREEN_300
                    is_signup["value"] = False
                    update_email_mode()
            else:
                response = await sign_in_user(
                    (email_field.value or "").strip(),
                    password_field.value or "",
                )
                if response.user:
                    await finish_login(response.user)
        except Exception as error:
            error_text = str(error)
            if mode["value"] == "student" and "Invalid login credentials" in error_text:
                error_text = "Student ID or PIN is incorrect."
            message.value = f"Error: {error_text}"
            message.color = ft.Colors.RED_300
        page.update()

    submit_button = ft.ElevatedButton(
        content=ft.Text("Student Login"),
        icon=ft.Icons.LOGIN,
        on_click=submit,
        width=320,
        height=50,
    )
    switch_button = ft.TextButton(
        content=ft.Text("New adult user? Create Account", color="#63E6BE"),
        visible=False,
    )

    def update_email_mode():
        signing_up = is_signup["value"]
        title.value = "Create Account" if signing_up else "Email Login"
        subtitle.value = (
            "For administrator, teacher, or adult users."
            if not signing_up
            else "Create an account using your own email address."
        )
        name_field.visible = signing_up
        submit_button.content = ft.Text("Create Account" if signing_up else "Email Login")
        switch_button.content = ft.Text(
            "Already have an account? Sign In"
            if signing_up
            else "New adult user? Create Account",
            color="#63E6BE",
        )

    async def switch_email_mode(e):
        is_signup["value"] = not is_signup["value"]
        message.value = ""
        update_email_mode()
        page.update()

    switch_button.on_click = switch_email_mode

    student_tab = ft.ElevatedButton(content=ft.Text("Student ID"), width=145)
    email_tab = ft.OutlinedButton(content=ft.Text("Email"), width=145)

    def set_tab_styles():
        if mode["value"] == "student":
            student_tab.bgcolor = "#0E4A54"
            email_tab.bgcolor = None
        else:
            student_tab.bgcolor = None
            email_tab.bgcolor = "#0E4A54"

    async def show_student(e):
        mode["value"] = "student"
        is_signup["value"] = False
        title.value = "Student Login"
        subtitle.value = "Use the Student ID and PIN given by your teacher."
        student_id_field.visible = True
        pin_field.visible = True
        name_field.visible = False
        email_field.visible = False
        password_field.visible = False
        switch_button.visible = False
        submit_button.content = ft.Text("Student Login")
        message.value = ""
        set_tab_styles()
        page.update()

    async def show_email(e):
        mode["value"] = "email"
        is_signup["value"] = False
        student_id_field.visible = False
        pin_field.visible = False
        email_field.visible = True
        password_field.visible = True
        switch_button.visible = True
        message.value = ""
        update_email_mode()
        set_tab_styles()
        page.update()

    student_tab.on_click = show_student
    email_tab.on_click = show_email
    set_tab_styles()

    return ft.Container(
        expand=True,
        bgcolor="#071426",
        alignment=ft.Alignment.CENTER,
        content=ft.Container(
            width=400,
            padding=30,
            border_radius=20,
            bgcolor="#10243E",
            content=ft.Column(
                [
                    ft.Text("Muraja'ah Quran App", size=18, color="#63E6BE"),
                    ft.Row(
                        [student_tab, email_tab],
                        alignment=ft.MainAxisAlignment.CENTER,
                        spacing=10,
                    ),
                    title,
                    subtitle,
                    ft.Container(height=4),
                    student_id_field,
                    pin_field,
                    name_field,
                    email_field,
                    password_field,
                    message,
                    submit_button,
                    switch_button,
                ],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=13,
                scroll=ft.ScrollMode.AUTO,
            ),
        ),
    )
