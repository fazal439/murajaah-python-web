import json
from pathlib import Path

import flet as ft


BASE = Path(__file__).resolve().parent
ACTIVE_COLOR = "#63E6BE"
INACTIVE_COLOR = "#8FA3B8"
CARD_COLOR = "#10243E"


def build_alternative_memory_card():
    def comparison_row(label, simple_value, ai_value):
        return ft.Row(
            [
                ft.Container(
                    expand=2,
                    content=ft.Text(
                        label, size=12, color=INACTIVE_COLOR
                    ),
                ),
                ft.Container(
                    expand=1,
                    content=ft.Text(
                        simple_value, size=14, color=ACTIVE_COLOR
                    ),
                ),
                ft.Container(
                    expand=1,
                    content=ft.Text(
                        ai_value, size=14, color=ACTIVE_COLOR
                    ),
                ),
            ],
            spacing=8,
        )

    try:
        report = json.loads(
            (BASE / "alternative_memory_report.json").read_text(
                encoding="utf-8"
            )
        )

        controls = [
            ft.Text(
                "Alternative Memory Tests",
                size=22,
                weight=ft.FontWeight.BOLD,
                color=ACTIVE_COLOR,
            ),
            ft.Text(
                "Saved exploratory comparisons under three "
                "assumed forgetting curves.",
                size=12,
                color=INACTIVE_COLOR,
            ),
            ft.Text(
                f'{report["runs_per_curve"]} runs per curve · '
                f'{report["learners_per_run"]} virtual learners per run',
                size=12,
                color=INACTIVE_COLOR,
            ),
            ft.Text(
                f'{report["simulated_ayahs_per_learner"]} simulated '
                f'ayahs per learner · {report["total_days"]} days · '
                f'{report["daily_revision_budget"]} revisions per day',
                size=12,
                color=INACTIVE_COLOR,
            ),
        ]

        curve_names = {
            "exponential": "Exponential",
            "power_law_shape_1": "Power law — shape 1",
            "power_law_shape_2": "Power law — shape 2",
        }

        for key, title in curve_names.items():
            scenario = report["scenarios"][key]
            simple = scenario["summary"]["round_robin"]
            ai = scenario["summary"]["ai_risk"]
            difference = scenario["paired_differences"][
                "mean_final_recall_probability"
            ]
            low, high = difference["bootstrap_95_percent_interval"]
            delta = difference["mean_ai_minus_round_robin"]

            if low <= 0 <= high:
                finding = (
                    "The interval includes zero: no clear difference "
                    "in final recall probability under this assumption."
                )
            elif high < 0:
                finding = (
                    "AI has lower final recall probability "
                    "under this assumption."
                )
            else:
                finding = (
                    "AI has higher final recall probability "
                    "under this assumption."
                )

            controls.extend(
                [
                    ft.Divider(),
                    ft.Text(
                        title,
                        size=18,
                        weight=ft.FontWeight.BOLD,
                        color=ACTIVE_COLOR,
                    ),
                    comparison_row("Measure", "Simple", "AI"),
                    comparison_row(
                        "Mean final recall probability",
                        f'{simple["mean_final_recall_probability"]:.2%}',
                        f'{ai["mean_final_recall_probability"]:.2%}',
                    ),
                    comparison_row(
                        "Final simulated success rate",
                        f'{simple["final_success_rate"]:.2%}',
                        f'{ai["final_success_rate"]:.2%}',
                    ),
                    comparison_row(
                        "Mean daily recall probability",
                        f'{simple["mean_daily_recall_probability"]:.2%}',
                        f'{ai["mean_daily_recall_probability"]:.2%}',
                    ),
                    comparison_row(
                        "Mean revisions",
                        f'{simple["mean_total_revisions"]:.0f}',
                        f'{ai["mean_total_revisions"]:.0f}',
                    ),
                    comparison_row(
                        "Mean fallback days",
                        f'{simple["mean_fallback_days"]:.4f}',
                        f'{ai["mean_fallback_days"]:.4f}',
                    ),
                    ft.Text(
                        "AI minus Simple final recall probability: "
                        f"{delta * 100:+.3f} percentage points",
                        size=13,
                        color=ACTIVE_COLOR,
                    ),
                    ft.Text(
                        "95% simulation interval: "
                        f"{low * 100:+.3f} to {high * 100:+.3f} "
                        "percentage points",
                        size=12,
                        color=INACTIVE_COLOR,
                    ),
                    ft.Text(
                        finding,
                        size=12,
                        color="#FFB86B",
                    ),
                ]
            )

        controls.extend(
            [
                ft.Divider(),
                ft.Text(
                    "Simple = fixed round-robin rotation. "
                    "AI = highest predicted failure risk.",
                    size=12,
                    color=INACTIVE_COLOR,
                ),
                ft.Text(
                    "The AI model was trained under exponential "
                    "forgetting and was not retrained for these tests.",
                    size=12,
                    color=INACTIVE_COLOR,
                ),
                ft.Text(
                    "Exploratory simulation only. These curves are "
                    "assumptions, not measured Quran learner memory. "
                    "Intervals describe simulation uncertainty; "
                    "real learners have not been validated.",
                    size=12,
                    color="#FFB86B",
                ),
            ]
        )

    except (OSError, ValueError, KeyError, TypeError) as error:
        print("Alternative memory dashboard error:", error)
        controls = [
            ft.Text(
                "Alternative memory results unavailable.",
                color=INACTIVE_COLOR,
            )
        ]

    return ft.Container(
        padding=18,
        bgcolor=CARD_COLOR,
        border_radius=20,
        content=ft.Column(controls, spacing=12),
    )