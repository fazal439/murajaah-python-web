import httpx


API_BASE_URL = "https://api.alquran.cloud/v1"


def get_surah_ayahs(surah_number):
    url = (
        f"{API_BASE_URL}/surah/{surah_number}/editions/"
        "quran-uthmani,en.asad"
    )

    response = httpx.get(url, timeout=20)
    response.raise_for_status()

    editions = response.json()["data"]

    arabic_ayahs = editions[0]["ayahs"]
    translation_ayahs = editions[1]["ayahs"]
    ayahs = []

    for arabic, translation in zip(
        arabic_ayahs,
        translation_ayahs,
    ):
        ayah_number = arabic["numberInSurah"]
        ayahs.append(
            {
                "number": ayah_number,
                "arabic": arabic["text"],
                "translation": translation["text"],
                "audio": (
                    "https://verses.quran.com/Alafasy/mp3/"
                    f"{surah_number:03d}{ayah_number:03d}.mp3"
                ),
            }
        )

    return ayahs
