import csv
import json
from pathlib import Path

from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler

BASE = Path(__file__).resolve().parent

FEATURES = [
    "previous_mistakes",
    "previous_response_seconds",
    "previous_audio_plays",
    "previous_attempt_count",
    "days_since_review",
    "word_count",
]


def main():
    with (BASE / "ai_dataset_test.csv").open(
        newline="", encoding="utf-8-sig"
    ) as file:
        rows = list(csv.DictReader(file))

    if not rows:
        print("Dataset is empty.")
        return

    X = [
        [float(row[name]) for name in FEATURES]
        for row in rows
    ]
    y = [int(row["next_attempt_failure"]) for row in rows]

    if set(y) != {0, 1}:
        print("Both successful and unsuccessful examples are needed.")
        return

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    model = LogisticRegression(max_iter=2000)
    model.fit(X_scaled, y)

    output = {
        "model_type": "logistic_regression",
        "purpose": "software_test_only",
        "validated": False,
        "training_examples": len(rows),
                "gap_min_days": min(
            float(row["days_since_review"]) for row in rows
        ),
        "gap_max_days": max(
            float(row["days_since_review"]) for row in rows
        ),
        "features": FEATURES,
        "classes": model.classes_.tolist(),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "coefficients": model.coef_[0].tolist(),
        "intercept": float(model.intercept_[0]),
    }

    path = BASE / "ai_model_test.json"
    path.write_text(json.dumps(output, indent=2), encoding="utf-8")

    print(f"Training examples: {len(rows)}")
    print("Logistic Regression fitted successfully.")
    print(f"Saved: {path.name}")
    print("Software test only. Accuracy not evaluated.")


if __name__ == "__main__":
    main()