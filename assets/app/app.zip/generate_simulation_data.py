import csv
import random
from pathlib import Path

from memory_simulator import HALF_LIFE_DAYS, recall_probability
from run_simulation import SUCCESS_MULTIPLIER, FAILURE_MULTIPLIER


OUTPUT = Path(__file__).resolve().parent / "simulation_dataset.csv"


def generate_data():
    rows = []

    for profile_index, profile in enumerate(
        ("weak", "medium", "strong")
    ):
        for number in range(100):
            learner_number = profile_index * 100 + number + 1
            seed = 10000 + learner_number

            memory_rng = random.Random(seed)
            gap_rng = random.Random(seed + 100000)
            recall_rng = random.Random(seed + 200000)

            half_life = (
                HALF_LIFE_DAYS[profile]
                * memory_rng.uniform(0.8, 1.2)
            )

            if number < 60:
                split = "train"
            elif number < 80:
                split = "validation"
            else:
                split = "test"

            successes = 0
            failures = 0
            consecutive_successes = 0
            previous_success = -1
            previous_gap = 0
            day = 0

            for attempt in range(20):
                gap = gap_rng.randint(1, 10)
                day += gap

                probability = recall_probability(gap, half_life)
                success = recall_rng.random() < probability

                # Features contain only information available
                # before this attempt's outcome.
                rows.append({
                    "learner_id": f"S{learner_number:03d}",
                    "split": split,
                    "memory_profile": profile,
                    "day": day,
                    "days_since_review": gap,
                    "previous_attempt_count": attempt,
                    "previous_successes": successes,
                    "previous_failures": failures,
                    "previous_success": previous_success,
                    "consecutive_successes": consecutive_successes,
                    "previous_gap_days": previous_gap,
                    "recall_failure": int(not success),
                    "data_source": "simulation",
                })

                if success:
                    successes += 1
                    consecutive_successes += 1
                    half_life *= SUCCESS_MULTIPLIER
                else:
                    failures += 1
                    consecutive_successes = 0
                    half_life *= FAILURE_MULTIPLIER

                previous_success = int(success)
                previous_gap = gap

    return rows


if __name__ == "__main__":
    rows = generate_data()

    with OUTPUT.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

    print(f"Created: {OUTPUT.name}")
    print("Virtual learners: 300")
    print(f"Examples: {len(rows)}")

    for split in ("train", "validation", "test"):
        group = [row for row in rows if row["split"] == split]
        learners = {row["learner_id"] for row in group}
        print(
            f"{split}: {len(learners)} learners, "
            f"{len(group)} examples"
        )

    print("Synthetic data only. No real student records.")
    print("AI has not been trained on this dataset yet.")