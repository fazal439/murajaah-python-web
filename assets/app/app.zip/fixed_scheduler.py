FIXED_INTERVAL_DAYS = 3


def is_review_due(
    current_day,
    last_review_day,
    interval_days=FIXED_INTERVAL_DAYS,
):
    if interval_days <= 0:
        raise ValueError("Interval must be positive.")

    if current_day < last_review_day:
        raise ValueError("Current day cannot be before last review.")

    return current_day - last_review_day >= interval_days


def get_revision_days(total_days=30, interval_days=3):
    if total_days < 1 or interval_days < 1:
        raise ValueError("Days and interval must be positive.")

    # Day 0: initial learning.
    # Final day: assessment before any further revision.
    return list(range(interval_days, total_days, interval_days))


if __name__ == "__main__":
    days = get_revision_days()

    print("Baseline: fixed revision every 3 days")
    print(f"Revision days: {days}")
    print(f"Total revisions: {len(days)}")
    print("Day 30: final assessment before revision")
    print("Assumed baseline. No AI used.")