import json
from pathlib import Path

import flet as ft


BASE = Path(__file__).resolve().parent
ACTIVE_COLOR = "#63E6BE"
INACTIVE_COLOR = "#8FA3B8"
CARD_COLOR = "#10243E"


def build_simulation_card():
    try:
        report = json.loads(
            (BASE / "repeated_simulation_report.json").read_text(
                encoding="utf-8"
            )
        )
        model = json.loads(
            (BASE / "simulation_ai_model.json").read_text(
                encoding="utf-8"
            )
        )

        fixed = report["summary"]["fixed"]
        ai = report["summary"]["ai_budgeted"]

        def comparison_row(label, fixed_value, ai_value):
            return ft.Row(
                [
                    ft.Container(
                        expand=2,
                        content=ft.Text(
                            label, size=12, color=INACTIVE_COLOR
                        ),
                    ),
                    ft.Container(
                        expand=1,
                        content=ft.Text(
                            fixed_value, size=14, color=ACTIVE_COLOR
                        ),
                    ),
                    ft.Container(
                        expand=1,
                        content=ft.Text(
                            ai_value, size=14, color=ACTIVE_COLOR
                        ),
                    ),
                ],
                spacing=8,
            )

        def difference_text(metric, label, percentage=False):
            result = report["paired_differences"][metric]
            value = result["mean_ai_minus_fixed"]
            low, high = result["bootstrap_95_percent_interval"]

            if percentage:
                values = (
                    f"{value * 100:+.2f} percentage points "
                    f"(95% interval: {low * 100:+.2f} "
                    f"to {high * 100:+.2f})"
                )
            else:
                values = (
                    f"{value:+.2f} "
                    f"(95% interval: {low:+.2f} to {high:+.2f})"
                )

            return ft.Text(
                f"{label}: {values}",
                size=12,
                color=INACTIVE_COLOR,
            )

        controls = [
            ft.Text(
                "Revision Scheduling Lab",
                size=22,
                weight=ft.FontWeight.BOLD,
                color=ACTIVE_COLOR,
            ),
            ft.Text(
                "Saved results from repeated virtual learner simulations",
                size=13,
                color=INACTIVE_COLOR,
            ),
            ft.Text(
                f'{report["runs"]} runs · '
                f'{report["learners_per_run"]} virtual learners per run',
                size=12,
                color=INACTIVE_COLOR,
            ),
            ft.Text(
                f'{fixed["learners"]} virtual learner cases, each tested '
                "with both schedules",
                size=12,
                color=INACTIVE_COLOR,
            ),
            ft.Text(
                f'{report["total_days"]} days per run · '
                "one simulated ayah per learner",
                size=12,
                color=INACTIVE_COLOR,
            ),
            ft.Text(
                "Maximum revisions per learner: "
                f'{report["maximum_revisions_per_learner"]}',
                size=12,
                color=INACTIVE_COLOR,
            ),
            comparison_row("Measure", "Fixed", "AI"),
            comparison_row(
                "Mean final recall probability",
                f'{fixed["mean_final_recall_probability"]:.1%}',
                f'{ai["mean_final_recall_probability"]:.1%}',
            ),
            comparison_row(
                "Final simulated success rate",
                f'{fixed["final_success_rate"]:.1%}',
                f'{ai["final_success_rate"]:.1%}',
            ),
            comparison_row(
                "Mean daily recall probability",
                f'{fixed["mean_daily_recall_probability"]:.1%}',
                f'{ai["mean_daily_recall_probability"]:.1%}',
            ),
            comparison_row(
                "Mean revisions",
                f'{fixed["mean_revisions"]:.2f}',
                f'{ai["mean_revisions"]:.2f}',
            ),
            ft.Divider(),
            ft.Text(
                "Paired differences: AI minus Fixed",
                size=14,
                color=ACTIVE_COLOR,
            ),
            difference_text(
                "mean_final_recall_probability",
                "Final recall probability",
                percentage=True,
            ),
            difference_text(
                "final_success_rate",
                "Final simulated success rate",
                percentage=True,
            ),
            difference_text(
                "mean_daily_recall_probability",
                "Daily recall probability",
                percentage=True,
            ),
            difference_text(
                "mean_revisions",
                "Revisions per learner",
            ),
            ft.Text(
                "Intervals describe simulation randomness under the "
                "assumed memory model; they exclude uncertainty about "
                "the memory model and real learners.",
                size=12,
                color=INACTIVE_COLOR,
            ),
            ft.Divider(),
            ft.Text(
                "AI prediction test accuracy: "
                f'{model["test_metrics"]["accuracy"]:.2%}',
                size=14,
                color=ACTIVE_COLOR,
            ),
            ft.Text(
                f'Tested on {model["test_examples"]} synthetic '
                "examples from separate virtual learners. "
                "Prediction accuracy is separate from scheduling results.",
                size=12,
                color=INACTIVE_COLOR,
            ),
            ft.Text(
                "Both schedules use the same learner seeds and maximum "
                "revision budget. Actual revision counts may differ.",
                size=12,
                color=INACTIVE_COLOR,
            ),
            ft.Text(
                "The budget constraint may override the AI risk-based gap.",
                size=12,
                color=INACTIVE_COLOR,
            ),
            ft.Text(
                "50-run evaluation · assumed memory model · "
                "not validated on real learners",
                size=12,
                color="#FFB86B",
            ),
        ]

    except (OSError, ValueError, KeyError, TypeError) as error:
        print("Simulation dashboard error:", error)
        controls = [
            ft.Text(
                "Simulation results unavailable.",
                color=INACTIVE_COLOR,
            )
        ]

    return ft.Container(
        padding=18,
        bgcolor=CARD_COLOR,
        border_radius=20,
        content=ft.Column(controls, spacing=12),
    )