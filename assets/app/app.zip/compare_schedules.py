import csv
import json
import math
import random
from pathlib import Path

from adaptive_scheduler import choose_interval, RISK_LIMIT
from fixed_scheduler import FIXED_INTERVAL_DAYS
from memory_simulator import HALF_LIFE_DAYS, recall_probability
from run_simulation import SUCCESS_MULTIPLIER, FAILURE_MULTIPLIER
from virtual_learners import create_virtual_learners


BASE = Path(__file__).resolve().parent
TOTAL_DAYS = 30
REVISION_BUDGET = 9


def simulate(learner, strategy):
    rng = random.Random(learner["random_seed"])
    half_life = (
        HALF_LIFE_DAYS[learner["memory_profile"]]
        * rng.uniform(0.8, 1.2)
    )
    draws = {
        day: rng.random()
        for day in range(1, TOTAL_DAYS + 1)
    }

    history = {
        "previous_attempt_count": 0,
        "previous_successes": 0,
        "previous_failures": 0,
        "previous_success": -1,
        "consecutive_successes": 0,
        "previous_gap_days": 0,
    }

    revision_days = []
    last_review_day = 0
    daily_probabilities = []

    def next_review(current_day):
        remaining = REVISION_BUDGET - len(revision_days)

        if remaining <= 0:
            return TOTAL_DAYS

        if strategy == "fixed":
            return current_day + FIXED_INTERVAL_DAYS

        gap, _ = choose_interval(history)

        # Spread the remaining budget across the remaining time.
        # This constraint may override the risk-based gap.
        minimum_gap = math.ceil(
            (TOTAL_DAYS - current_day) / (remaining + 1)
        )
        return current_day + max(gap, minimum_gap)

    due_day = next_review(0)

    for day in range(1, TOTAL_DAYS + 1):
        gap = day - last_review_day
        probability = recall_probability(gap, half_life)
        daily_probabilities.append(probability)

        # Final assessment happens before any day-30 revision.
        if day == TOTAL_DAYS:
            final_probability = probability
            final_success = draws[day] < probability
            break

        if day != due_day:
            continue

        success = draws[day] < probability
        revision_days.append(day)
        history["previous_attempt_count"] += 1

        if success:
            history["previous_successes"] += 1
            history["consecutive_successes"] += 1
            half_life *= SUCCESS_MULTIPLIER
        else:
            history["previous_failures"] += 1
            history["consecutive_successes"] = 0
            half_life *= FAILURE_MULTIPLIER

        history["previous_success"] = int(success)
        history["previous_gap_days"] = gap
        last_review_day = day
        due_day = next_review(day)

    return {
        "learner_id": learner["learner_id"],
        "memory_profile": learner["memory_profile"],
        "strategy": strategy,
        "revisions": len(revision_days),
        "revision_days": ",".join(map(str, revision_days)),
        "final_recall_probability": final_probability,
        "final_recall_success": int(final_success),
        "mean_daily_recall_probability": (
            sum(daily_probabilities) / len(daily_probabilities)
        ),
        "data_source": "simulation",
    }


def summarise(rows):
    return {
        "learners": len(rows),
        "mean_revisions": sum(
            row["revisions"] for row in rows
        ) / len(rows),
        "mean_final_recall_probability": sum(
            row["final_recall_probability"] for row in rows
        ) / len(rows),
        "final_success_rate": sum(
            row["final_recall_success"] for row in rows
        ) / len(rows),
        "mean_daily_recall_probability": sum(
            row["mean_daily_recall_probability"] for row in rows
        ) / len(rows),
    }


def main():
    results = [
        simulate(learner, strategy)
        for learner in create_virtual_learners()
        for strategy in ("fixed", "ai_budgeted")
    ]

    summaries = {}

    for strategy in ("fixed", "ai_budgeted"):
        group = [
            row for row in results
            if row["strategy"] == strategy
        ]
        summary = summarise(group)
        summaries[strategy] = summary

        print(f"\n{strategy}")
        print(
            "Mean final recall probability: "
            f'{summary["mean_final_recall_probability"]:.1%}'
        )
        print(
            "Simulated final success rate: "
            f'{summary["final_success_rate"]:.1%}'
        )
        print(
            "Mean daily recall probability: "
            f'{summary["mean_daily_recall_probability"]:.1%}'
        )
        print(f'Mean revisions: {summary["mean_revisions"]:.2f}')

    with (BASE / "schedule_comparison.csv").open(
        "w", newline="", encoding="utf-8"
    ) as file:
        writer = csv.DictWriter(file, fieldnames=list(results[0]))
        writer.writeheader()
        writer.writerows(results)

    report = {
        "purpose": "simulation_prototype",
        "total_days": TOTAL_DAYS,
        "maximum_revisions_per_learner": REVISION_BUDGET,
        "risk_limit": RISK_LIMIT,
        "budget_policy": "spread_remaining_budget",
        "validated_on_real_learners": False,
        "summary": summaries,
        "results": results,
    }

    (BASE / "schedule_comparison.json").write_text(
        json.dumps(report, indent=2, allow_nan=False),
        encoding="utf-8",
    )

    print("\nSaved: schedule_comparison.csv")
    print("Saved: schedule_comparison.json")
    print("One simulation run only; repeated experiments pending.")


if __name__ == "__main__":
    main()