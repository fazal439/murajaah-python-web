# Muraja'ah Quran App

A gamified Quran revision application developed with Python, Flet, and Supabase.

## Research Project

**Title:** Implementation and Evaluation of a Gamified Al-Quran Mobile Application for Enhancing Engagement, Motivation, and Memorisation Outcomes.

## Main Features

- Quran revision for all 37 Surahs of Juz Amma
- Word-order quizzes
- Points and XP
- Dynamic levels and learner ranks
- Daily revision streak
- Mastery status: New, Weak, Medium, and Strong
- Live Progress and Statistics pages
- User registration and secure login
- Separate progress for every user
- Quiz-attempt history
- Supabase cloud database
- Sign Out and profile information

## Technologies

- Python
- Flet
- Supabase
- HTTPX
- Quran API

## Project Files

- `app.py` — main application and dashboard
- `revision.py` — Quran revision and quizzes
- `quran_api.py` — Quran data loading
- `surahs.py` — Juz Amma Surah information
- `auth_view.py` — Sign Up and Sign In screen
- `supabase_client.py` — authentication and database functions
- `requirements.txt` — Python dependencies
- `.env.example` — safe configuration example

## Installation

Create a virtual environment:

```powershell
py -3.13 -m venv .venv
```

Install the required packages:

```powershell
& ".\.venv\Scripts\python.exe" -m pip install -r requirements.txt
```

## Supabase Configuration

Create a private `.env` file in the project folder:

```env
SUPABASE_URL=your_supabase_project_url
SUPABASE_PUBLISHABLE_KEY=your_public_publishable_key
```

Never upload the real `.env` file to a public repository.

## Run the App

```powershell
& ".\.venv\Scripts\python.exe" app.py
```

## Database Tables

- `profiles`
- `surah_progress`
- `quiz_attempts`

Row Level Security is enabled so each user can only access their own data.

## Developer

Fazal Qadir  
MSc (Research) in Artificial Intelligence  
Universiti Malaysia Sarawak (UNIMAS)