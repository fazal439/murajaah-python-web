import json
import math
from functools import lru_cache
from pathlib import Path


RISK_LIMIT = 0.30
MAX_GAP_DAYS = 10


@lru_cache(maxsize=1)
def load_model():
    path = Path(__file__).resolve().parent / "simulation_ai_model.json"
    model = json.loads(path.read_text(encoding="utf-8"))

    if model["purpose"] != "virtual_learner_simulation":
        raise ValueError("A simulation model is required.")

    if model["classes"] != [0, 1]:
        raise ValueError("Unexpected model classes.")

    return model


def predict_failure(history, gap_days):
    if not 1 <= gap_days <= MAX_GAP_DAYS:
        raise ValueError("Gap must be between 1 and 10 days.")

    model = load_model()
    features = dict(history)
    features["days_since_review"] = gap_days
    score = float(model["intercept"])

    for index, name in enumerate(model["features"]):
        value = float(features[name])
        scale = float(model["scale"][index])

        if not math.isfinite(value) or scale <= 0:
            raise ValueError("Invalid model input.")

        scaled = (value - model["mean"][index]) / scale
        score += scaled * model["coefficients"][index]

    if not math.isfinite(score):
        raise ValueError("Invalid model score.")

    if score >= 0:
        return 1 / (1 + math.exp(-score))

    exp_score = math.exp(score)
    return exp_score / (1 + exp_score)


def choose_interval(history, risk_limit=RISK_LIMIT):
    if not 0 < risk_limit < 1:
        raise ValueError("Risk limit must be between 0 and 1.")

    # Choose the largest gap before predicted risk exceeds the limit.
    selected_gap = 1

    for gap in range(1, MAX_GAP_DAYS + 1):
        risk = predict_failure(history, gap)

        if risk > risk_limit:
            break

        selected_gap = gap

    return selected_gap, predict_failure(history, selected_gap)


if __name__ == "__main__":
    history = {
        "previous_attempt_count": 5,
        "previous_successes": 3,
        "previous_failures": 2,
        "previous_success": 1,
        "consecutive_successes": 2,
        "previous_gap_days": 3,
    }

    gap, risk = choose_interval(history)

    print("Example history: 5 previous revisions")
    print(f"Recommended next revision: after {gap} day(s)")
    print(f"Predicted failure risk at that gap: {risk:.1%}")
    print("If no gap meets the limit, the minimum gap is used.")
    print("Simulation model only. Real learners not validated.")