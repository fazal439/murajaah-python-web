-- Run this once in Supabase: SQL Editor > New query > Run

alter table public.quiz_attempts
add column if not exists username text;

alter table public.surah_progress
add column if not exists username text;

-- Add readable names to existing records.
update public.quiz_attempts qa
set username = coalesce(
    nullif(u.raw_user_meta_data ->> 'full_name', ''),
    split_part(u.email, '@', 1),
    'Murajaah User'
)
from auth.users u
where qa.user_id = u.id
  and (qa.username is null or qa.username = '');

update public.surah_progress sp
set username = coalesce(
    nullif(u.raw_user_meta_data ->> 'full_name', ''),
    split_part(u.email, '@', 1),
    'Murajaah User'
)
from auth.users u
where sp.user_id = u.id
  and (sp.username is null or sp.username = '');

-- Only the current Monday-to-Sunday scores appear in this view.
create or replace view public.weekly_leaderboard as
select
    qa.user_id,
    coalesce(max(qa.username), 'Murajaah User') as username,
    coalesce(sum(qa.points), 0)::integer as weekly_xp,
    count(*)::integer as completed_ayahs
from public.quiz_attempts qa
where qa.completed_at >= date_trunc('week', now())
group by qa.user_id
order by weekly_xp desc;

revoke all on public.weekly_leaderboard from anon;
grant select on public.weekly_leaderboard to authenticated;
