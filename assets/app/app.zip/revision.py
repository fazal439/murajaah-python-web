import random
from datetime import datetime, timezone
from time import perf_counter

import flet as ft
import flet_audio as fta

from supabase_client import (
    pop_celebrations,
    save_quiz_attempt,
    save_surah_progress,
)
from quran_api import get_surah_ayahs


ACTIVE_COLOR = "#63E6BE"
INACTIVE_COLOR = "#8FA3B8"
CARD_COLOR = "#10243E"
CORRECT_COLOR = "#155E55"
WRONG_COLOR = "#6B3038"


def build_revision_view(page, surah, on_back, target_ayah=None):
    try:
        ayahs = get_surah_ayahs(surah["number"])
        if not ayahs:
            raise ValueError("No ayahs returned.")

        total_ayahs = len(ayahs)

        if target_ayah is not None:
            ayahs = [
                ayah for ayah in ayahs
                if int(ayah["number"]) == int(target_ayah)
            ]
            if not ayahs:
                raise ValueError("Requested ayah was not found.")
    except Exception:
        return ft.Column(
            [
                ft.Text(
                    "Could not load Quran data",
                    size=24,
                    weight=ft.FontWeight.BOLD,
                ),
                ft.Text(
                    "Please check your internet connection.",
                    color=INACTIVE_COLOR,
                ),
                ft.Container(
                    padding=15,
                    bgcolor=CARD_COLOR,
                    border_radius=15,
                    on_click=lambda e: on_back(),
                    content=ft.Text("‹ Back", color=ACTIVE_COLOR),
                ),
            ],
            spacing=15,
        )

    state = {
        "ayah_index": 0,
        "word_index": 0,
        "selected_words": [],
        "used_options": set(),
        "options": [],
        "points": 0,
        "mistakes": 0,
        "ayah_mistakes": 0,
        "audio_plays": 0,
        "started_at": None,
        "start_timer": None,
    }

    def show_reward_popup():
        rewards = pop_celebrations()
        if not rewards:
            return

        def close_dialog(e):
            dialog.open = False
            page.update()

        dialog = ft.AlertDialog(
            modal=True,
            bgcolor=CARD_COLOR,
            title=ft.Text(
                "🎉 Congratulations!",
                color=ACTIVE_COLOR,
                weight=ft.FontWeight.BOLD,
            ),
            content=ft.Column(
                [
                    ft.Text(
                        reward,
                        size=16,
                        text_align=ft.TextAlign.CENTER,
                    )
                    for reward in rewards
                ],
                tight=True,
                spacing=12,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            actions=[
                ft.TextButton("Continue", on_click=close_dialog)
            ],
            actions_alignment=ft.MainAxisAlignment.CENTER,
        )
        page.overlay.append(dialog)
        dialog.open = True
        page.update()

    audio_player = fta.Audio(
        src=ayahs[0]["audio"],
        autoplay=False,
        volume=1,
    )
    page.services.append(audio_player)

    ayah_position = ft.Text(
        "", size=14, color=INACTIVE_COLOR
    )
    points_text = ft.Text(
        "⭐ 0 points",
        color=ACTIVE_COLOR,
        weight=ft.FontWeight.BOLD,
    )
    mistakes_text = ft.Text(
        "0 mistakes",
        color="#FFB86B",
        weight=ft.FontWeight.BOLD,
    )
    answer_text = ft.Text(
        "",
        size=31,
        color=ACTIVE_COLOR,
        text_align=ft.TextAlign.CENTER,
    )
    status_text = ft.Text(
        "Select the first correct word",
        color=INACTIVE_COLOR,
        text_align=ft.TextAlign.CENTER,
    )
    progress_bar = ft.ProgressBar(
        value=0,
        color=ACTIVE_COLOR,
        bgcolor="#203650",
    )
    answer_box = ft.Container(
        height=145,
        padding=20,
        bgcolor=CARD_COLOR,
        border_radius=22,
        alignment=ft.Alignment.CENTER,
        content=answer_text,
    )
    choices_area = ft.Column(
        spacing=12,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
    )
    next_button = ft.Container(
        visible=False,
        padding=15,
        bgcolor=CORRECT_COLOR,
        border_radius=15,
        alignment=ft.Alignment.CENTER,
        content=ft.Text(
            "Next Ayah ›",
            size=17,
            color=ACTIVE_COLOR,
            weight=ft.FontWeight.BOLD,
        ),
    )

    def current_words():
        return ayahs[state["ayah_index"]]["arabic"].split()

    def make_word_button(option_id, word):
        async def select_word(e):
            await choose_word(option_id)

        return ft.Container(
            width=145,
            padding=14,
            bgcolor="#F7F3E8",
            border_radius=15,
            alignment=ft.Alignment.CENTER,
            on_click=select_word,
            content=ft.Text(
                word,
                size=24,
                color="#15202B",
                text_align=ft.TextAlign.CENTER,
            ),
        )

    def rebuild_choices():
        available = [
            item
            for item in state["options"]
            if item[0] not in state["used_options"]
        ]
        rows = []
        for start in range(0, len(available), 4):
            row_items = available[start:start + 4]
            rows.append(
                ft.Row(
                    [
                        make_word_button(option_id, word)
                        for option_id, word in row_items
                    ],
                    spacing=10,
                    alignment=ft.MainAxisAlignment.CENTER,
                )
            )
        choices_area.controls = rows

    def update_score():
        points_text.value = f'⭐ {state["points"]} points'
        mistakes_text.value = f'{state["mistakes"]} mistakes'

    async def choose_word(option_id):
        words = current_words()

        if state["word_index"] >= len(words):
            return
        if option_id in state["used_options"]:
            return

        selected_option = next(
            (
                item
                for item in state["options"]
                if item[0] == option_id
            ),
            None,
        )
        if selected_option is None:
            return

        selected_word = selected_option[1]
        expected_word = words[state["word_index"]]

        if selected_word == expected_word:
            state["selected_words"].append(selected_word)
            state["used_options"].add(option_id)
            state["word_index"] += 1
            state["points"] += 10

            answer_text.value = " ".join(state["selected_words"])
            status_text.value = "Correct! +10 points"
            status_text.color = ACTIVE_COLOR

            rebuild_choices()
            update_score()

            if state["word_index"] >= len(words):
                state["points"] += 50
                update_score()

                status_text.value = (
                    "Ayah completed! Bonus +50 points"
                )
                status_text.color = ACTIVE_COLOR
                answer_box.bgcolor = CORRECT_COLOR

                try:
                    await save_quiz_attempt(
                        surah_number=surah["number"],
                        ayah_number=int(ayahs[state["ayah_index"]]["number"]),
                        points=(len(words) * 10) + 50,
                        mistakes=state["ayah_mistakes"],
                        started_at=state["started_at"],
                        response_time_seconds=round(
                            perf_counter() - state["start_timer"], 3
                        ),
                        audio_plays=state["audio_plays"],
                        word_count=len(words),
                        completed_at=datetime.now(
                            timezone.utc
                        ).isoformat(),
                    )
                    show_reward_popup()
                    print("Quiz attempt saved to Supabase")
                except Exception as error:
                    print("Quiz attempt save error:", error)
                    status_text.value = (
                        "Ayah completed, but the result could not "
                        "be saved. Please check your connection."
                    )
                    status_text.color = "#FFB86B"

                next_button.visible = True
                if state["ayah_index"] == len(ayahs) - 1:
                    next_button.content.value = (
                        "Finish Revision ✓"
                        if target_ayah is not None
                        else "Finish Surah ✓"
                    )
        else:
            state["mistakes"] += 1
            state["ayah_mistakes"] += 1
            update_score()

            status_text.value = "Wrong word — try again"
            status_text.color = "#FF8A8A"
            answer_box.bgcolor = WRONG_COLOR

        page.update()

    def prepare_ayah(update_page=True):
        ayah = ayahs[state["ayah_index"]]
        words = ayah["arabic"].split()

        state["word_index"] = 0
        state["ayah_mistakes"] = 0
        state["audio_plays"] = 0
        state["started_at"] = datetime.now(timezone.utc).isoformat()
        state["start_timer"] = perf_counter()
        state["selected_words"] = []
        state["used_options"] = set()
        state["options"] = list(enumerate(words))
        random.shuffle(state["options"])

        ayah_position.value = (
            f'{surah["english"]} · '
            f'Ayah {ayah["number"]} of {total_ayahs}'
        )
        answer_text.value = "  ".join(["ــــ"] * len(words))
        status_text.value = "Select the first correct word"
        status_text.color = INACTIVE_COLOR
        answer_box.bgcolor = CARD_COLOR
        next_button.visible = False
        next_button.content.value = "Next Ayah ›"
        progress_bar.value = (
            (state["ayah_index"] + 1) / len(ayahs)
        )

        rebuild_choices()
        update_score()

        if update_page:
            page.update()

    async def listen_ayah(e):
        if state["word_index"] >= len(current_words()):
            return

        state["audio_plays"] += 1
        audio_player.src = ayahs[state["ayah_index"]]["audio"]
        page.update()

        try:
            await audio_player.play()
        except Exception as error:
            print(f"Audio playback error: {error}")

    async def next_ayah(e):
        if state["word_index"] != len(current_words()):
            return

        if state["ayah_index"] < len(ayahs) - 1:
            state["ayah_index"] += 1
            prepare_ayah()
        else:
            await show_completion()

    async def show_completion():
        if target_ayah is not None:
            on_back()
            return
        try:
            await save_surah_progress(
                surah_number=surah["number"],
                completed_ayahs=len(ayahs),
                total_ayahs=len(ayahs),
                points=state["points"],
                mistakes=state["mistakes"],
            )
            show_reward_popup()
            print("Progress saved to Supabase")
        except Exception as error:
            print("Progress save error:", error)

        revision_view.controls = [
            ft.Container(
                expand=True,
                alignment=ft.Alignment.CENTER,
                content=ft.Column(
                    [
                        ft.Text(
                            "🏆",
                            size=70,
                            text_align=ft.TextAlign.CENTER,
                        ),
                        ft.Text(
                            "Surah Completed!",
                            size=30,
                            weight=ft.FontWeight.BOLD,
                            color=ACTIVE_COLOR,
                            text_align=ft.TextAlign.CENTER,
                        ),
                        ft.Text(
                            surah["english"],
                            size=22,
                            text_align=ft.TextAlign.CENTER,
                        ),
                        ft.Text(
                            f'⭐ {state["points"]} total points',
                            size=20,
                            color=ACTIVE_COLOR,
                            text_align=ft.TextAlign.CENTER,
                        ),
                        ft.Text(
                            f'{state["mistakes"]} total mistakes',
                            size=17,
                            color="#FFB86B",
                            text_align=ft.TextAlign.CENTER,
                        ),
                        ft.Container(
                            padding=16,
                            bgcolor=CORRECT_COLOR,
                            border_radius=15,
                            alignment=ft.Alignment.CENTER,
                            on_click=lambda e: on_back(),
                            content=ft.Text(
                                "Back to Surahs",
                                weight=ft.FontWeight.BOLD,
                            ),
                        ),
                    ],
                    spacing=16,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                ),
            )
        ]
        page.update()

    next_button.on_click = next_ayah

    revision_view = ft.Column(
        [
            ft.Row(
                [
                    ft.Container(
                        on_click=lambda e: on_back(),
                        content=ft.Text(
                            "✕", size=24, color=ACTIVE_COLOR
                        ),
                    ),
                    ft.Column(
                        [
                            ft.Text(
                                surah["arabic"],
                                size=25,
                                color=ACTIVE_COLOR,
                            ),
                            ayah_position,
                        ],
                        spacing=2,
                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    ),
                    points_text,
                ],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            ),
            progress_bar,
            answer_box,
            status_text,
            choices_area,
            ft.Row(
                [
                    ft.Container(
                        padding=14,
                        bgcolor=CARD_COLOR,
                        border_radius=15,
                        on_click=listen_ayah,
                        content=ft.Text(
                            "▶ Listen",
                            color=ACTIVE_COLOR,
                            weight=ft.FontWeight.BOLD,
                        ),
                    ),
                    mistakes_text,
                ],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            ),
            next_button,
        ],
        spacing=16,
        scroll=ft.ScrollMode.AUTO,
        expand=True,
    )

    prepare_ayah(update_page=False)
    return revision_view