import random

from fixed_scheduler import get_revision_days
from memory_simulator import HALF_LIFE_DAYS, recall_probability
from virtual_learners import create_virtual_learners


# Assumed effects of revision with corrective feedback.
SUCCESS_MULTIPLIER = 1.25
FAILURE_MULTIPLIER = 1.05


def simulate_fixed(learner, total_days=30):
    rng = random.Random(learner["random_seed"])

    half_life = (
        HALF_LIFE_DAYS[learner["memory_profile"]]
        * rng.uniform(0.8, 1.2)
    )

    # One repeatable random draw per day.
    draws = {
        day: rng.random()
        for day in range(1, total_days + 1)
    }

    last_review_day = 0
    successful_reviews = 0
    revision_days = get_revision_days(total_days)

    for day in revision_days:
        probability = recall_probability(
            day - last_review_day,
            half_life,
        )
        success = draws[day] < probability

        if success:
            successful_reviews += 1
            half_life *= SUCCESS_MULTIPLIER
        else:
            half_life *= FAILURE_MULTIPLIER

        # Feedback/relearning occurs after each review.
        last_review_day = day

    final_probability = recall_probability(
        total_days - last_review_day,
        half_life,
    )

    return {
        "learner_id": learner["learner_id"],
        "memory_profile": learner["memory_profile"],
        "revisions": len(revision_days),
        "successful_reviews": successful_reviews,
        "final_recall_probability": final_probability,
        "final_recall_success": draws[total_days] < final_probability,
        "data_source": "simulation",
    }


if __name__ == "__main__":
    results = [
        simulate_fixed(learner)
        for learner in create_virtual_learners()
    ]

    print("Fixed schedule: 30 days, one ayah per learner")

    for profile in ("weak", "medium", "strong"):
        group = [
            row for row in results
            if row["memory_profile"] == profile
        ]
        mean_probability = sum(
            row["final_recall_probability"] for row in group
        ) / len(group)

        successes = sum(
            row["final_recall_success"] for row in group
        )

        print(
            f"{profile}: mean final recall probability "
            f"{mean_probability:.1%}; "
            f"simulated final successes {successes}/{len(group)}"
        )

    print("9 revisions per learner.")
    print("Assumed simulation only. AI comparison not added yet.")