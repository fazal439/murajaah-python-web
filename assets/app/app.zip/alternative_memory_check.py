import hashlib
import json
import math
from pathlib import Path
from statistics import mean

import multi_ayah_simulation as simulation
from repeat_experiments import confidence_interval
from virtual_learners import create_virtual_learners


BASE = Path(__file__).resolve().parent
RUNS = 50

METRICS = (
    "mean_final_recall_probability",
    "final_success_rate",
    "mean_daily_recall_probability",
    "mean_total_revisions",
)

ORIGINAL_RECALL = simulation.recall_probability


def power_law_recall(days, half_life, shape):
    days = float(days)
    half_life = float(half_life)

    if not math.isfinite(days) or days < 0:
        raise ValueError("Invalid elapsed time.")

    if not math.isfinite(half_life) or half_life <= 0:
        raise ValueError("Invalid half-life.")

    factor = 2 ** (1 / shape) - 1
    return (1 + factor * days / half_life) ** (-shape)


def power_law_shape_1(days, half_life):
    return power_law_recall(days, half_life, 1.0)


def power_law_shape_2(days, half_life):
    return power_law_recall(days, half_life, 2.0)


SCENARIOS = (
    ("exponential", ORIGINAL_RECALL),
    ("power_law_shape_1", power_law_shape_1),
    ("power_law_shape_2", power_law_shape_2),
)


def check_curves():
    # All curves start at 1 and reach 0.5 at one half-life.
    for name, function in SCENARIOS:
        for half_life in (1.0, 3.0, 7.0):
            if not math.isclose(function(0, half_life), 1.0):
                raise RuntimeError(f"{name}: invalid initial recall.")

            if not math.isclose(
                function(half_life, half_life), 0.5
            ):
                raise RuntimeError(f"{name}: invalid half-life.")

            values = [
                function(day, half_life)
                for day in range(simulation.TOTAL_DAYS + 1)
            ]

            if any(
                not math.isfinite(value) or not 0 <= value <= 1
                for value in values
            ):
                raise RuntimeError(f"{name}: invalid probabilities.")

            if any(
                later > earlier
                for earlier, later in zip(values, values[1:])
            ):
                raise RuntimeError(f"{name}: recall increases with time.")


def main():
    check_curves()

    templates = create_virtual_learners()
    expected_revisions = (
        simulation.DAILY_BUDGET * (simulation.TOTAL_DAYS - 1)
    )

    all_results = []
    all_runs = []
    scenario_reports = {}

    try:
        for scenario_name, recall_function in SCENARIOS:
            simulation.recall_probability = recall_function

            scenario_results = []
            differences = {metric: [] for metric in METRICS}

            for run_id in range(1, RUNS + 1):
                cohort = []

                for index, template in enumerate(templates):
                    learner = dict(template)
                    learner["learner_id"] = (
                        f'R{run_id:03d}_{template["learner_id"]}'
                    )

                    # New seeds; shared across curves and schedules.
                    learner["random_seed"] = (
                        5000000 + run_id * 100 + index
                    )

                    for strategy in simulation.STRATEGIES:
                        result, _, _ = simulation.simulate_learner(
                            learner, strategy
                        )

                        if result["total_revisions"] != expected_revisions:
                            raise RuntimeError(
                                "Revision budget was not respected."
                            )

                        result["run_id"] = run_id
                        result["memory_curve"] = scenario_name
                        cohort.append(result)

                scenario_results.extend(cohort)
                summaries = {}

                for strategy in simulation.STRATEGIES:
                    summary = simulation.summarise_learners([
                        row for row in cohort
                        if row["strategy"] == strategy
                    ])

                    summaries[strategy] = summary
                    all_runs.append({
                        "memory_curve": scenario_name,
                        "run_id": run_id,
                        "strategy": strategy,
                        **summary,
                    })

                for metric in METRICS:
                    differences[metric].append(
                        summaries["ai_risk"][metric]
                        - summaries["round_robin"][metric]
                    )

                if run_id % 10 == 0:
                    print(
                        f"{scenario_name}: {run_id}/{RUNS} runs",
                        flush=True,
                    )

            overall = {
                strategy: simulation.summarise_learners([
                    row for row in scenario_results
                    if row["strategy"] == strategy
                ])
                for strategy in simulation.STRATEGIES
            }

            paired = {
                metric: {
                    "mean_ai_minus_round_robin": mean(values),
                    "bootstrap_95_percent_interval": (
                        confidence_interval(values)
                    ),
                }
                for metric, values in differences.items()
            }

            scenario_reports[scenario_name] = {
                "summary": overall,
                "paired_differences": paired,
            }
            all_results.extend(scenario_results)

    finally:
        simulation.recall_probability = ORIGINAL_RECALL

    source_files = (
        "alternative_memory_check.py",
        "multi_ayah_simulation.py",
        "adaptive_scheduler.py",
        "memory_simulator.py",
        "run_simulation.py",
        "virtual_learners.py",
        "repeat_experiments.py",
        "compare_schedules.py",
        "fixed_scheduler.py",
        "simulation_ai_model.json",
    )

    report = {
        "purpose": "exploratory_alternative_memory_curve_check",
        "runs_per_curve": RUNS,
        "learners_per_run": len(templates),
        "virtual_cases_per_curve": RUNS * len(templates),
        "total_days": simulation.TOTAL_DAYS,
        "simulated_ayahs_per_learner": simulation.AYAH_COUNT,
        "daily_revision_budget": simulation.DAILY_BUDGET,
        "revisions_per_learner_per_schedule": expected_revisions,
        "equal_revision_counts_verified": True,
        "seed_rule": "5000000 + run_id * 100 + learner_index",
        "paired_randomness": (
            "Shared initial memory factors and item-day random draws "
            "across schedules and memory curves."
        ),
        "curve_definitions": {
            "exponential": "p = 2 ** (-days / half_life)",
            "power_law_shape_1": (
                "p = (1 + days / half_life) ** (-1)"
            ),
            "power_law_shape_2": (
                "p = (1 + (sqrt(2) - 1) * days / half_life) ** (-2)"
            ),
        },
        "curve_matching": (
            "All curves have p(0) = 1 and p(half_life) = 0.5. "
            "Other parts of their shapes differ."
        ),
        "initial_half_life_days": simulation.HALF_LIFE_DAYS,
        "learner_variation": "Uniform factor 0.8 to 1.2",
        "item_variation": "Uniform factor 0.7 to 1.3",
        "success_multiplier": simulation.SUCCESS_MULTIPLIER,
        "failure_multiplier": simulation.FAILURE_MULTIPLIER,
        "initial_learning": (
            "All items learned on day 0; initial learning cost excluded."
        ),
        "baseline_policy": "Fixed round-robin rotation",
        "ai_policy": (
            "Highest predicted failure risk with oldest-first fallback."
        ),
        "risk_threshold_used": False,
        "model_retrained": False,
        "model_training_memory_curve": "exponential",
        "primary_outcome": "mean_final_recall_probability",
        "validated_on_real_learners": False,
        "design_status": (
            "Exploratory checks added after inspecting earlier results."
        ),
        "interval_scope": (
            "Run-level bootstrap uncertainty within each assumed "
            "memory curve. Does not quantify real-learner uncertainty "
            "or establish which memory curve is correct."
        ),
        "scope": (
            "Power-law curves are mathematical stress-test assumptions, "
            "not measured Quran memory models. The frozen AI may be "
            "miscalibrated under alternative curves. Review duration "
            "and interference are not modelled."
        ),
        "scenarios": scenario_reports,
        "source_sha256": {
            name: hashlib.sha256(
                (BASE / name).read_bytes()
            ).hexdigest()
            for name in source_files
        },
    }

    simulation.save_csv(
        "alternative_memory_results.csv", all_results
    )
    simulation.save_csv(
        "alternative_memory_runs.csv", all_runs
    )

    (BASE / "alternative_memory_report.json").write_text(
        json.dumps(report, indent=2, allow_nan=False),
        encoding="utf-8",
    )

    for name, scenario in scenario_reports.items():
        print(f"\n{name}")

        for strategy, summary in scenario["summary"].items():
            print(
                f"{strategy}: final recall "
                f'{summary["mean_final_recall_probability"]:.2%}, '
                f'revisions {summary["mean_total_revisions"]:.0f}, '
                f'fallback days {summary["mean_fallback_days"]:.2f}'
            )

        difference = scenario["paired_differences"][
            "mean_final_recall_probability"
        ]
        low, high = difference["bootstrap_95_percent_interval"]

        print(
            "AI minus Simple: "
            f'{difference["mean_ai_minus_round_robin"] * 100:+.3f} '
            "percentage points"
        )
        print(
            "95% simulation interval: "
            f"{low * 100:+.3f} to {high * 100:+.3f}"
        )

    print("\nSaved alternative_memory_report.json and CSV files.")
    print("Exploratory simulation only; no real-learner validation.")


if __name__ == "__main__":
    main()