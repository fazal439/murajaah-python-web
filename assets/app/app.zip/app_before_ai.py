from datetime import datetime, timedelta, timezone
import flet as ft
from surahs import JUZ_30_SURAHS
from quran_api import get_surah_ayahs
from revision import build_revision_view
from auth_view import build_auth_view
from supabase_client import (
    get_current_user,
    get_user_progress,
    get_user_quiz_attempts,
    get_weekly_leaderboard,
    get_user_badges,
    get_daily_challenge,
    get_daily_bonus_xp,
    get_is_admin,
    get_admin_reports,
    get_admin_database_overview,
    get_admin_user_details,
    get_admin_table_records,
    get_account_type,
    get_student_code,
    admin_set_user_blocked,
    admin_delete_user,
    admin_create_student,
    admin_reset_student_pin,
    refresh_user_data,
    sign_out_user,
)
def main(page: ft.Page):
    page.title = "Murajaah Quran App"
    page.theme_mode = ft.ThemeMode.DARK
    page.bgcolor = "#071426"
    page.padding = 0
    page.window.width = 430
    page.window.height = 850

    active_color = "#63E6BE"
    inactive_color = "#8FA3B8"
    card_color = "#10243E"
    nav_labels = {}
    nav_containers = {}
    content_holder = ft.Container(expand=True, padding=20)

    def title_section(title, subtitle):
        return ft.Column(
            [
                ft.Text(
                    title,
                    size=28,
                    weight=ft.FontWeight.BOLD,
                ),
                ft.Text(
                    subtitle,
                    size=13,
                    color=inactive_color,
                ),
            ],
            spacing=2,
        )

    def statistic_card(value, title, color):
        return ft.Container(
            expand=True,
            padding=15,
            bgcolor=card_color,
            border_radius=18,
            content=ft.Column(
                [
                    ft.Text(
                        value,
                        size=24,
                        weight=ft.FontWeight.BOLD,
                        color=color,
                    ),
                    ft.Text(
                        title,
                        size=12,
                        color=inactive_color,
                    ),
                ],
                spacing=3,
            ),
        )

    def start_revision(surah):
        content_holder.content = build_revision_view(
            page,
            surah,
            lambda: show_surah(surah),
        )
        page.update()

    def show_surah(surah):
        content_holder.content = ft.Column(
            [
                ft.Container(
                    on_click=lambda e: show_page("Murajaah"),
                    content=ft.Text(
                        "‹ Back to Surahs",
                        color=active_color,
                        size=15,
                    ),
                ),
                ft.Container(height=10),
                ft.Text(
                    surah["arabic"],
                    size=40,
                    color=active_color,
                    text_align=ft.TextAlign.CENTER,
                ),
                ft.Text(
                    surah["english"],
                    size=25,
                    weight=ft.FontWeight.BOLD,
                    text_align=ft.TextAlign.CENTER,
                ),
                ft.Text(
                    f'Surah {surah["number"]} · '
                    f'{surah["ayahs"]} ayahs',
                    color=inactive_color,
                    text_align=ft.TextAlign.CENTER,
                ),
                ft.Container(height=25),
                ft.Container(
                    padding=25,
                    bgcolor=card_color,
                    border_radius=22,
                    content=ft.Column(
                        [
                            ft.Text(
                                "Ready for Murajaah?",
                                size=22,
                                weight=ft.FontWeight.BOLD,
                            ),
                            ft.Text(
                                "Review this Surah ayah by ayah "
                                "and record your mistakes.",
                                color=inactive_color,
                            ),
                            ft.Container(height=10),
                            ft.Container(
                                on_click=lambda e: start_revision(surah),
                                padding=15,
                                bgcolor="#0E4A54",
                                border_radius=15,
                                alignment=ft.Alignment.CENTER,
                                content=ft.Text(
                                    "▶ Start Revision",
                                    size=17,
                                    weight=ft.FontWeight.BOLD,
                                    color=active_color,
                                ),
                            ),
                        ]
                    ),
                ),
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            scroll=ft.ScrollMode.AUTO,
        )
        page.update()

    def surah_card(surah, status="New"):
                        
        return ft.Container(
            padding=15,
            margin=8,
            bgcolor=card_color,
            border_radius=18,
            on_click=lambda e, selected=surah: show_surah(selected),
            content=ft.Row(
                [
                    ft.Container(
                        width=55,
                        height=55,
                        bgcolor="#123A55",
                        border_radius=28,
                        alignment=ft.Alignment.CENTER,
                        content=ft.Text(
                            surah["arabic"],
                            size=15,
                            color=active_color,
                            text_align=ft.TextAlign.CENTER,
                        ),
                    ),
                    ft.Column(
                        [
                            ft.Text(
                                surah["english"],
                                size=16,
                                weight=ft.FontWeight.BOLD,
                            ),
                            ft.Text(
                                f'{status} · {surah["ayahs"]} ayahs',
                                size=12,
                                color=inactive_color,
                            ),
                        ],
                        spacing=3,
                        expand=True,
                    ),
                    ft.Text("›", size=30, color=active_color),
                ]
            ),
        )

    def build_home():
        try:
            home_progress = get_user_progress()
        except Exception as error:
            print("Home progress loading error:", error)
            home_progress = []

        reviewed_surahs = len(home_progress)
        progress_by_surah = {
            item["surah_number"]: item
            for item in home_progress
        }

        def get_surah_status(surah_number):
            progress = progress_by_surah.get(surah_number)

            if not progress:
                return "New"

            mastery = float(
                progress["mastery_percentage"]
            )

            if mastery >= 80:
                return "Strong"

            if mastery >= 40:
                return "Medium"

            return "Weak"
        total_xp = sum(
            item["points"] for item in home_progress
        ) + get_daily_bonus_xp()
        daily_challenge = get_daily_challenge()
        daily_progress = int(daily_challenge.get("progress_count") or 0)
        daily_target = int(daily_challenge.get("target_count") or 3)
        daily_complete = bool(daily_challenge.get("completed"))
        average_mastery = round(
            sum(
                float(item["mastery_percentage"])
                for item in home_progress
            ) / reviewed_surahs
        ) if reviewed_surahs else 0
        try:
            quiz_attempts = get_user_quiz_attempts()
        except Exception as error:
            print("Streak loading error:", error)
            quiz_attempts = []

        activity_dates = set()

        for attempt in quiz_attempts:
            completed_at = attempt.get("completed_at")

            if completed_at:
                attempt_date = datetime.fromisoformat(
                    completed_at.replace("Z", "+00:00")
                ).date()

                activity_dates.add(attempt_date)

        today = datetime.now(timezone.utc).date()
        yesterday = today - timedelta(days=1)

        if today in activity_dates:
            streak_day = today
        elif yesterday in activity_dates:
            streak_day = yesterday
        else:
            streak_day = None

        streak_count = 0

        while streak_day in activity_dates:
            streak_count += 1
            streak_day -= timedelta(days=1)
        return ft.Column(
            [
                ft.Row(
                    [
                        title_section(
                            "Muraja'ah",
                            "Juz 30 · An-Naba → An-Nas",
                        ),
                        ft.Container(
                            padding=12,
                            bgcolor=card_color,
                            border_radius=20,
                            content=ft.Text(f"🔥 {streak_count}", size=16),
                        ),
                    ]
                ),
                ft.Container(height=8),
                ft.Container(
                    padding=18,
                    bgcolor="#0E3150",
                    border_radius=22,
                    content=ft.Row(
                        [
                            ft.Column(
                                [
                                    ft.Text(
                                        f"Level {total_xp // 100 + 1}",
                                        size=22,
                                        weight=ft.FontWeight.BOLD,
                                        color=active_color,
                                    ),
                                    ft.Text(
    "Newcomer"
    if total_xp < 100
    else "Learner"
    if total_xp < 200
    else "Consistent Learner"
    if total_xp < 500
    else "Muraja'ah Master"
),
                                ],
                                expand=True,
                            ),
                            ft.Column(
                                [
                                    ft.Text(
                                       f"{total_xp} XP",
                                        size=20,
                                        weight=ft.FontWeight.BOLD,
                                    ),
                                    ft.Text(
                                        f"Next level: {(total_xp // 100 + 1) * 100} XP",
                                        size=11,
                                    ),
                                ],
                                horizontal_alignment=(
                                    ft.CrossAxisAlignment.END
                                ),
                            ),
                        ]
                    ),
                ),
                ft.Container(
                    padding=18,
                    bgcolor="#143B32" if daily_complete else card_color,
                    border_radius=20,
                    content=ft.Column(
                        [
                            ft.Row(
                                [
                                    ft.Text(
                                        "🎯 Daily Challenge",
                                        size=18,
                                        weight=ft.FontWeight.BOLD,
                                        expand=True,
                                    ),
                                    ft.Text(
                                        "Completed +50 XP" if daily_complete
                                        else f"{daily_progress}/{daily_target} Ayahs",
                                        color=active_color if daily_complete else "#FFB86B",
                                        weight=ft.FontWeight.BOLD,
                                    ),
                                ]
                            ),
                            ft.Text(
                                "Complete 3 Ayahs today",
                                size=12,
                                color=inactive_color,
                            ),
                            ft.ProgressBar(
                                value=min(daily_progress / daily_target, 1),
                                color=active_color,
                                bgcolor="#294766",
                            ),
                        ],
                        spacing=8,
                    ),
                ),
                ft.Row(
                    [
                        statistic_card(
                           f"{reviewed_surahs}/37",
                            "Surahs reviewed",
                            active_color,
                        ),
                        statistic_card(
                            f"{max(0, 37 - reviewed_surahs)}",
                            "Due now",
                            "#FFB86B",
                        ),
                        statistic_card(
                            f"{average_mastery}%",
                            "Mastery",
                            "#74C0FC",
                        ),
                    ],
                    spacing=10,
                ),
                ft.Text(
                    "Due for revision",
                    size=20,
                    weight=ft.FontWeight.BOLD,
                ),
                ft.Column(
                    [
    surah_card(
        surah,
        get_surah_status(surah["number"]),
    )
    for surah in JUZ_30_SURAHS
],
                    spacing=0,
                ),
            ],
            spacing=15,
            scroll=ft.ScrollMode.AUTO,
        )

    def build_murajaah():
        try:
            murajaah_progress = get_user_progress()
        except Exception as error:
            print("Murajaah status loading error:", error)
            murajaah_progress = []

        murajaah_progress_by_surah = {
            item["surah_number"]: item
            for item in murajaah_progress
        }

        def get_murajaah_status(surah_number):
            progress = murajaah_progress_by_surah.get(
                surah_number
            )

            if not progress:
                return "New"

            mastery = float(
                progress["mastery_percentage"]
            )

            if mastery >= 80:
                return "Strong"

            if mastery >= 40:
                return "Medium"

            return "Weak"
        return ft.Column(
            [
                title_section(
                    "All Surahs",
                    "37 Surahs · Juz Amma",
                ),
                ft.Container(height=10),
                ft.Column(
                    [
    surah_card(
        surah,
        get_murajaah_status(surah["number"]),
    )
    for surah in JUZ_30_SURAHS
],
                    spacing=0,
                ),
            ],
            scroll=ft.ScrollMode.AUTO,
        )

    def build_progress():
        try:
            saved_progress = get_user_progress()
        except Exception as error:
            print("Progress loading error:", error)
            saved_progress = []

        reviewed_surahs = len(saved_progress)
        new_count = max(0, 37 - reviewed_surahs)

        weak_count = sum(
            1 for item in saved_progress
            if item["mastery_percentage"] < 40
        )

        medium_count = sum(
            1 for item in saved_progress
            if 40 <= item["mastery_percentage"] < 80
        )

        strong_count = sum(
            1 for item in saved_progress
            if item["mastery_percentage"] >= 80
        )

        progress_items = [
            ("New", str(new_count), active_color),
            ("Weak", str(weak_count), "#FF6B6B"),
            ("Medium", str(medium_count), "#FFB86B"),
            ("Strong", str(strong_count), "#74C0FC"),
        ]

        return ft.Column(
            [
                title_section(
                    "Progress",
                    "Recall strength across all Surahs",
                ),
                ft.Container(height=15),
                *[
                    ft.Container(
                        padding=18,
                        bgcolor=card_color,
                        border_radius=18,
                        content=ft.Row(
                            [
                                ft.Text(
                                    name,
                                    size=17,
                                    weight=ft.FontWeight.BOLD,
                                ),
                                ft.Text(
                                    value,
                                    size=22,
                                    weight=ft.FontWeight.BOLD,
                                    color=color,
                                ),
                            ],
                            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                        ),
                    )
                    for name, value, color in progress_items
                ],
            ],
            spacing=12,
            scroll=ft.ScrollMode.AUTO,
        )

    def build_statistics():
        try:
            statistics_progress = get_user_progress()
        except Exception as error:
            print("Statistics loading error:", error)
            statistics_progress = []

        statistics_reviewed = len(statistics_progress)

        statistics_xp = sum(
            item["points"] for item in statistics_progress
        ) + get_daily_bonus_xp()

        statistics_mastery = round(
            sum(
                float(item["mastery_percentage"])
                for item in statistics_progress
            ) / statistics_reviewed
        ) if statistics_reviewed else 0

        statistics_weak = sum(
            1 for item in statistics_progress
            if float(item["mastery_percentage"]) < 40
        )

        statistics_medium = sum(
            1 for item in statistics_progress
            if 40 <= float(item["mastery_percentage"]) < 80
        )

        statistics_strong = sum(
            1 for item in statistics_progress
            if float(item["mastery_percentage"]) >= 80
        )
        return ft.Column(
            [
                title_section(
                    "Statistics",
                    "Your Murajaah performance",
                ),
                ft.Container(height=15),
                ft.Row(
                    [
                       statistic_card(
    str(statistics_xp // 100 + 1),
    "Level",
    active_color,
),
statistic_card(
    str(statistics_xp),
    "Total XP",
    "#FFB86B",
),
statistic_card(
    f"{statistics_mastery}%",
    "Mastery",
    "#74C0FC",
),
                    ],
                    spacing=10,
                ),
                ft.Container(
                    padding=20,
                    bgcolor=card_color,
                    border_radius=20,
                    content=ft.Column(
                        [
                            ft.Text(
                                "Recall distribution",
                                size=20,
                                weight=ft.FontWeight.BOLD,
                            ),
                            ft.Text(
                                f"New Surahs: {max(0, 37 - statistics_reviewed)}",
                                color=active_color,
                            ),
                           ft.Text(f"Weak Surahs: {statistics_weak}"),
                           ft.Text(f"Medium Surahs: {statistics_medium}"),
                            ft.Text(f"Strong Surahs: {statistics_strong}"),
                        ],
                        spacing=12,
                    ),
                ),
            ],
            spacing=15,
        )

    def build_profile():
        profile_user = get_current_user()

        if profile_user:
            profile_metadata = profile_user.user_metadata or {}
            profile_name = (
                profile_metadata.get("full_name")
                or "Muraja'ah User"
            )
            if get_account_type() == "student":
                profile_subtitle = (
                    f"{profile_name} • Student ID: {get_student_code()}"
                )
            else:
                profile_email = profile_user.email or ""
                profile_subtitle = f"{profile_name} • {profile_email}"
        else:
            profile_subtitle = "Guest reciter"

        unlocked_badges = {
            badge.get("badge_code")
            for badge in get_user_badges()
        }
        badge_details = [
            ("first_step", "🌱", "First Step", "Complete your first ayah"),
            ("xp_100", "⭐", "100 XP", "Earn 100 total XP"),
            ("streak_3", "🔥", "3-Day Streak", "Practise for 3 consecutive days"),
            ("surah_master", "📖", "Surah Master", "Complete your first Surah"),
            ("xp_500", "👑", "500 XP Champion", "Earn 500 total XP"),
        ]
        badge_cards = []
        for code, icon, name, description in badge_details:
            unlocked = code in unlocked_badges
            badge_cards.append(
                ft.Container(
                    width=155,
                    padding=14,
                    bgcolor="#0E3150" if unlocked else "#111C2A",
                    border_radius=16,
                    opacity=1 if unlocked else 0.55,
                    content=ft.Column(
                        [
                            ft.Text(icon if unlocked else "🔒", size=28),
                            ft.Text(name, weight=ft.FontWeight.BOLD),
                            ft.Text(
                                "Unlocked" if unlocked else description,
                                size=10,
                                color=active_color if unlocked else inactive_color,
                            ),
                        ],
                        spacing=4,
                    ),
                )
            )
        async def logout_user(e):
            try:
                await sign_out_user()
                page.overlay.clear()

                auth_screen = build_auth_view(
                    page,
                    login_success,
                )

                page.overlay.append(auth_screen)
                page.update()

            except Exception as error:
                print("Sign out error:", error)
        return ft.Column(
            [
                title_section(
                    "Profile & Settings",
                    profile_subtitle,
                ),
                ft.Container(height=15),
                ft.Text(
                    "My Badges",
                    size=20,
                    weight=ft.FontWeight.BOLD,
                ),
                ft.Row(
                    badge_cards,
                    wrap=True,
                    spacing=10,
                    run_spacing=10,
                ),
                ft.Container(
                    padding=18,
                    bgcolor=card_color,
                    border_radius=18,
                    content=ft.Column(
                        [
                            ft.Text(
                                "APPEARANCE",
                                color=active_color,
                                weight=ft.FontWeight.BOLD,
                            ),
                            ft.Row(
                                [
                                    ft.Text(
                                        "Use dark theme",
                                        expand=True,
                                    ),
                                    ft.Switch(value=True),
                                ]
                            ),
                            ft.Text(
                                "NOTIFICATIONS",
                                color=active_color,
                                weight=ft.FontWeight.BOLD,
                            ),
                                                                    ft.Row(
                        [
                            ft.Text(
                                "Daily reminders",
                                expand=True,
                            ),
                            ft.Switch(value=False),
                        ],
                    ),
                    ft.Text(
                        "SECURITY",
                        color=active_color,
                        weight=ft.FontWeight.BOLD,
                    ),
                    ft.Row(
                        [
                            ft.Text(
                                "Fingerprint lock",
                                expand=True,
                            ),
                            ft.Switch(value=False),
                        ],
                    ),
                    ft.Divider(color="#294766"),
                    ft.ElevatedButton(
                        "Sign Out",
                        icon=ft.Icons.LOGOUT,
                        on_click=logout_user,
                        width=220,
                        height=48,
                        bgcolor="#C0392B",
                        color=ft.Colors.WHITE,
                    ),
                                                ],
                    spacing=15,
                ),
            ),
        ],
        spacing=15,
        scroll=ft.ScrollMode.AUTO,
    )

    def build_leaderboard():
        leaders = get_weekly_leaderboard()
        leader_rows = []

        for index, leader in enumerate(leaders):
            rank = index + 1
            medal = "🥇" if rank == 1 else "🥈" if rank == 2 else "🥉" if rank == 3 else f"#{rank}"
            leader_rows.append(
                ft.Container(
                    padding=15,
                    bgcolor="#0E3150" if rank <= 3 else card_color,
                    border_radius=16,
                    content=ft.Row(
                        [
                            ft.Text(medal, size=22, width=45),
                            ft.Column(
                                [
                                    ft.Text(
                                        leader.get("username") or "Murajaah User",
                                        size=16,
                                        weight=ft.FontWeight.BOLD,
                                    ),
                                    ft.Text(
                                        f'{leader.get("completed_ayahs", 0)} ayahs completed',
                                        size=11,
                                        color=inactive_color,
                                    ),
                                ],
                                spacing=2,
                                expand=True,
                            ),
                            ft.Text(
                                f'{leader.get("weekly_xp", 0)} XP',
                                color=active_color,
                                weight=ft.FontWeight.BOLD,
                            ),
                        ]
                    ),
                )
            )

        if not leader_rows:
            leader_rows.append(
                ft.Container(
                    padding=20,
                    bgcolor=card_color,
                    border_radius=16,
                    content=ft.Text(
                        "No XP earned this week yet.",
                        color=inactive_color,
                    ),
                )
            )

        return ft.Column(
            [
                title_section(
                    "Weekly Leaderboard 🏆",
                    "Ranking resets automatically every Monday",
                ),
                ft.Column(leader_rows, spacing=10),
            ],
            spacing=15,
            scroll=ft.ScrollMode.AUTO,
        )
    

    def admin_notice(message, is_error=False):
        notice = ft.SnackBar(
            content=ft.Text(message),
            bgcolor="#8B2635" if is_error else "#0E6655",
        )
        page.overlay.append(notice)
        notice.open = True
        page.update()

    def record_card(record):
        lines = []
        for key, value in record.items():
            if key in ("id", "user_id"):
                continue
            display_key = key.replace("_", " ").title()
            display_value = "—" if value is None else str(value)
            if len(display_value) > 120:
                display_value = display_value[:117] + "..."
            lines.append(
                ft.Text(
                    f"{display_key}: {display_value}",
                    size=11,
                    selectable=True,
                )
            )
        if not lines:
            lines.append(ft.Text("No readable fields", color=inactive_color))
        return ft.Container(
            padding=12,
            bgcolor=card_color,
            border_radius=14,
            content=ft.Column(lines, spacing=4),
        )

    def build_admin_user_details(report, details):
        sections = [
            ("Student Account", "student_account"),
            ("Surah Progress", "surah_progress"),
            ("Quiz Attempts", "quiz_attempts"),
            ("Badges", "badges"),
            ("Daily Challenges", "daily_challenges"),
        ]
        section_controls = []
        for title, key in sections:
            rows = details.get(key) or []
            if isinstance(rows, dict):
                rows = [rows] if rows else []
            section_controls.extend(
                [
                    ft.Text(
                        f"{title} ({len(rows)})",
                        size=18,
                        weight=ft.FontWeight.BOLD,
                        color=active_color,
                    ),
                    ft.Column(
                        [record_card(row) for row in rows]
                        if rows
                        else [ft.Text("No records", color=inactive_color)],
                        spacing=8,
                    ),
                ]
            )

        return ft.Column(
            [
                ft.TextButton(
                    "‹ Back to Admin Panel",
                    on_click=lambda e: show_page("Admin"),
                ),
                title_section(
                    report.get("username") or "Murajaah User",
                    report.get("student_code")
                    or report.get("email")
                    or "Complete user database record",
                ),
                *section_controls,
            ],
            spacing=14,
            scroll=ft.ScrollMode.AUTO,
        )

    def build_admin_table(table_name, records):
        return ft.Column(
            [
                ft.TextButton(
                    "‹ Back to Admin Panel",
                    on_click=lambda e: show_page("Admin"),
                ),
                title_section(
                    f"Database · {table_name}",
                    f"Showing {len(records)} most recent records",
                ),
                ft.Column(
                    [record_card(row) for row in records]
                    if records
                    else [ft.Text("No records found", color=inactive_color)],
                    spacing=8,
                ),
            ],
            spacing=14,
            scroll=ft.ScrollMode.AUTO,
        )

    def user_details_click(report):
        async def handler(e):
            try:
                details = await get_admin_user_details(report.get("user_id"))
                content_holder.content = build_admin_user_details(
                    report,
                    details,
                )
                page.update()
            except Exception as error:
                admin_notice(f"Could not load user record: {error}", True)
        return handler

    def database_table_click(table_key, table_name):
        async def handler(e):
            try:
                records = await get_admin_table_records(table_key, 100)
                content_holder.content = build_admin_table(
                    table_name,
                    records,
                )
                page.update()
            except Exception as error:
                admin_notice(f"Could not load database records: {error}", True)
        return handler

    def admin_confirmation(title, message, action_text, action):
        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text(title),
            content=ft.Text(message),
        )

        def cancel(e):
            dialog.open = False
            page.update()

        async def confirm(e):
            dialog.open = False
            page.update()
            try:
                success_message = await action()
                content_holder.content = build_admin()
                page.update()
                admin_notice(success_message)
            except Exception as error:
                admin_notice(f"Admin action failed: {error}", True)

        dialog.actions = [
            ft.TextButton("Cancel", on_click=cancel),
            ft.TextButton(action_text, on_click=confirm),
        ]
        page.overlay.append(dialog)
        dialog.open = True
        page.update()

    def block_user_click(report):
        def handler(e):
            currently_blocked = bool(report.get("is_blocked"))
            new_status = not currently_blocked

            async def action():
                await admin_set_user_blocked(
                    report.get("user_id"),
                    new_status,
                )
                return (
                    "User access blocked successfully."
                    if new_status
                    else "User access restored successfully."
                )

            admin_confirmation(
                "Restore User Access" if currently_blocked else "Block User",
                (
                    "This user will be able to use the app again."
                    if currently_blocked
                    else "This user will not be able to sign in or use the app."
                ),
                "Unblock" if currently_blocked else "Block",
                action,
            )
        return handler

    def delete_user_click(report):
        def handler(e):
            async def action():
                await admin_delete_user(report.get("user_id"))
                return "User account and all progress were deleted permanently."

            admin_confirmation(
                "Permanently Delete User",
                (
                    f'Delete {report.get("username") or "this user"}? '
                    "The account, progress, attempts, badges and challenges "
                    "will be permanently removed. This cannot be undone."
                ),
                "Delete Permanently",
                action,
            )
        return handler

    def show_student_credentials(student_name, student_code, pin):
        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("Student Account Created ✅"),
            content=ft.Column(
                [
                    ft.Text(student_name, weight=ft.FontWeight.BOLD),
                    ft.Text(
                        f"Student ID: {student_code}",
                        size=20,
                        color=active_color,
                        selectable=True,
                    ),
                    ft.Text(
                        f"PIN: {pin}",
                        size=20,
                        color="#FFB86B",
                        selectable=True,
                    ),
                    ft.Text(
                        "Write down or send these details now. The PIN is not shown again.",
                        size=12,
                        color=inactive_color,
                    ),
                ],
                tight=True,
                spacing=10,
            ),
        )

        def close(e):
            dialog.open = False
            page.update()

        dialog.actions = [ft.TextButton("Done", on_click=close)]
        page.overlay.append(dialog)
        dialog.open = True
        page.update()

    def create_student_click(e):
        name_field = ft.TextField(
            label="Student full name",
            prefix_icon=ft.Icons.PERSON,
        )
        pin_field = ft.TextField(
            label="Choose a 6-digit PIN",
            prefix_icon=ft.Icons.PIN,
            password=True,
            can_reveal_password=True,
            keyboard_type=ft.KeyboardType.NUMBER,
            max_length=6,
        )
        error_text = ft.Text("", color=ft.Colors.RED_300)
        dialog = ft.AlertDialog(
            modal=True,
            title=ft.Text("Create Student Account"),
            content=ft.Column(
                [
                    ft.Text(
                        "No student email is needed. A Student ID will be generated automatically.",
                        size=12,
                        color=inactive_color,
                    ),
                    name_field,
                    pin_field,
                    error_text,
                ],
                tight=True,
                spacing=10,
            ),
        )

        def cancel(e):
            dialog.open = False
            page.update()

        async def create(e):
            error_text.value = ""
            try:
                pin = pin_field.value or ""
                result = await admin_create_student(name_field.value, pin)
                dialog.open = False
                content_holder.content = build_admin()
                page.update()
                show_student_credentials(
                    result.get("student_name") or name_field.value,
                    result.get("student_code") or "",
                    pin,
                )
            except Exception as error:
                error_text.value = str(error)
                page.update()

        dialog.actions = [
            ft.TextButton("Cancel", on_click=cancel),
            ft.ElevatedButton("Create Student", on_click=create),
        ]
        page.overlay.append(dialog)
        dialog.open = True
        page.update()

    def reset_student_pin_click(report):
        def handler(e):
            pin_field = ft.TextField(
                label="New 6-digit PIN",
                prefix_icon=ft.Icons.PIN,
                password=True,
                can_reveal_password=True,
                keyboard_type=ft.KeyboardType.NUMBER,
                max_length=6,
            )
            error_text = ft.Text("", color=ft.Colors.RED_300)
            dialog = ft.AlertDialog(
                modal=True,
                title=ft.Text("Reset Student PIN"),
                content=ft.Column(
                    [
                        ft.Text(
                            f'{report.get("username") or "Student"} · '
                            f'{report.get("student_code") or ""}'
                        ),
                        pin_field,
                        error_text,
                    ],
                    tight=True,
                    spacing=10,
                ),
            )

            def cancel(e):
                dialog.open = False
                page.update()

            async def reset(e):
                try:
                    await admin_reset_student_pin(
                        report.get("user_id"),
                        pin_field.value,
                    )
                    dialog.open = False
                    page.update()
                    admin_notice("Student PIN reset successfully.")
                except Exception as error:
                    error_text.value = str(error)
                    page.update()

            dialog.actions = [
                ft.TextButton("Cancel", on_click=cancel),
                ft.ElevatedButton("Reset PIN", on_click=reset),
            ]
            page.overlay.append(dialog)
            dialog.open = True
            page.update()
        return handler

    def build_admin():
        if not get_is_admin():
            return ft.Column(
                [
                    title_section("Admin Panel", "Access denied"),
                    ft.Text(
                        "Only the administrator can view this page.",
                        color="#FF6B6B",
                    ),
                ]
            )

        reports = get_admin_reports()
        database_overview = get_admin_database_overview()
        total_users = len(reports)
        total_xp = sum(int(row.get("total_xp") or 0) for row in reports)
        total_ayahs = sum(
            int(row.get("ayahs_completed") or 0) for row in reports
        )
        active_users = sum(
            1
            for row in reports
            if row.get("last_activity") and not row.get("is_blocked")
        )

        database_cards = []
        for table in database_overview:
            database_cards.append(
                ft.Container(
                    width=190,
                    padding=14,
                    bgcolor=card_color,
                    border_radius=16,
                    content=ft.Column(
                        [
                            ft.Text(
                                str(table.get("record_count") or 0),
                                size=22,
                                color="#74C0FC",
                                weight=ft.FontWeight.BOLD,
                            ),
                            ft.Text(
                                table.get("table_name") or "Database",
                                weight=ft.FontWeight.BOLD,
                            ),
                            ft.TextButton(
                                "View Records",
                                on_click=database_table_click(
                                    table.get("table_key"),
                                    table.get("table_name") or "Database",
                                ),
                            ),
                        ],
                        spacing=3,
                    ),
                )
            )

        user_cards = []
        current_user = get_current_user()
        current_user_id = str(current_user.id) if current_user else ""
        for report in reports:
            username = report.get("username") or "Murajaah User"
            account_type = report.get("account_type") or "adult"
            is_student = account_type == "student"
            account_label = (
                f'Student ID: {report.get("student_code") or "—"}'
                if is_student
                else (report.get("email") or "")
            )
            user_xp = int(report.get("total_xp") or 0)
            is_blocked = bool(report.get("is_blocked"))
            is_self = str(report.get("user_id")) == current_user_id
            last_activity = report.get("last_activity")
            last_text = (
                last_activity[:10]
                if isinstance(last_activity, str) and last_activity
                else "No activity yet"
            )
            user_cards.append(
                ft.Container(
                    padding=16,
                    bgcolor=card_color,
                    border_radius=18,
                    content=ft.Column(
                        [
                            ft.Row(
                                [
                                    ft.Column(
                                        [
                                            ft.Text(
                                                username,
                                                size=17,
                                                weight=ft.FontWeight.BOLD,
                                            ),
                                            ft.Text(
                                                account_label,
                                                size=11,
                                                color=inactive_color,
                                            ),
                                        ],
                                        spacing=2,
                                        expand=True,
                                    ),
                                    ft.Column(
                                        [
                                            ft.Text(
                                                "BLOCKED" if is_blocked else "ACTIVE",
                                                color="#FF6B6B" if is_blocked else active_color,
                                                size=11,
                                                weight=ft.FontWeight.BOLD,
                                            ),
                                            ft.Text(
                                                f"Level {user_xp // 100 + 1} · {user_xp} XP",
                                                color=active_color,
                                                weight=ft.FontWeight.BOLD,
                                            ),
                                        ],
                                        spacing=2,
                                        horizontal_alignment=ft.CrossAxisAlignment.END,
                                    ),
                                ]
                            ),
                            ft.Divider(color="#294766"),
                            ft.Text(
                                f'Surahs: {report.get("surahs_reviewed", 0)}  ·  '
                                f'Ayahs: {report.get("ayahs_completed", 0)}  ·  '
                                f'Mistakes: {report.get("mistakes", 0)}  ·  '
                                f'Badges: {report.get("badges_count", 0)}',
                                size=12,
                            ),
                            ft.Text(
                                f"Last activity: {last_text}",
                                size=11,
                                color=inactive_color,
                            ),
                            ft.Row(
                                [
                                    ft.OutlinedButton(
                                        "View Record",
                                        on_click=user_details_click(report),
                                    ),
                                    ft.OutlinedButton(
                                        "Reset PIN",
                                        visible=is_student,
                                        on_click=reset_student_pin_click(report),
                                    ),
                                    ft.ElevatedButton(
                                        "Unblock" if is_blocked else "Block",
                                        disabled=is_self,
                                        on_click=block_user_click(report),
                                    ),
                                    ft.TextButton(
                                        "Delete",
                                        disabled=is_self,
                                        on_click=delete_user_click(report),
                                    ),
                                ],
                                spacing=6,
                                wrap=True,
                            ),
                            ft.Text(
                                "Administrator account is protected."
                                if is_self
                                else "",
                                size=10,
                                color=inactive_color,
                            ),
                        ],
                        spacing=8,
                    ),
                )
            )

        if not user_cards:
            user_cards.append(
                ft.Text("No registered users found.", color=inactive_color)
            )

        return ft.Column(
            [
                title_section(
                    "Admin Panel 🛡️",
                    "Secure user management and database reports",
                ),
                ft.ElevatedButton(
                    "Create Student Account",
                    icon=ft.Icons.PERSON_ADD,
                    on_click=create_student_click,
                ),
                ft.Row(
                    [
                        statistic_card(str(total_users), "Users", active_color),
                        statistic_card(str(active_users), "Active", "#74C0FC"),
                        statistic_card(str(total_ayahs), "Ayahs", "#FFB86B"),
                        statistic_card(str(total_xp), "Total XP", "#C084FC"),
                    ],
                    spacing=10,
                ),
                ft.Text(
                    "Database Access",
                    size=20,
                    weight=ft.FontWeight.BOLD,
                ),
                ft.Row(
                    database_cards,
                    spacing=10,
                    scroll=ft.ScrollMode.AUTO,
                ),
                ft.Text(
                    "User Records",
                    size=20,
                    weight=ft.FontWeight.BOLD,
                ),
                ft.Column(user_cards, spacing=10),
            ],
            spacing=15,
            scroll=ft.ScrollMode.AUTO,
        )

    page_builders = {
        "Home": build_home,
        "Murajaah": build_murajaah,
        "Progress": build_progress,
        "Statistics": build_statistics,
        "Leaders": build_leaderboard,
        "Admin": build_admin,
        "Profile": build_profile,
    }

    def show_page(page_name):
        content_holder.content = page_builders[page_name]()

        for name, label_control in nav_labels.items():
            label_control.color = (
                active_color
                if name == page_name
                else inactive_color
            )

        page.update()

    navigation_items = [
        ("🏠", "Home"),
        ("📖", "Murajaah"),
        ("📈", "Progress"),
        ("📊", "Statistics"),
        ("🏆", "Leaders"),
        ("🛡️", "Admin"),
        ("👤", "Profile"),
    ]

    navigation_controls = []

    for icon, label in navigation_items:
        label_control = ft.Text(
            label,
            size=10,
            color=active_color if label == "Home" else inactive_color,
        )
        nav_labels[label] = label_control

        nav_container = ft.Container(
                expand=True,
                padding=5,
                alignment=ft.Alignment.CENTER,
                visible=(label != "Admin" or get_is_admin()),
                on_click=lambda e, name=label: show_page(name),
                content=ft.Column(
                    [
                        ft.Text(icon, size=20),
                        label_control,
                    ],
                    spacing=2,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                ),
            )
        nav_containers[label] = nav_container
        navigation_controls.append(nav_container)

    bottom_navigation = ft.Container(
        bgcolor=card_color,
        height=75,
        padding=10,
        content=ft.Row(
            navigation_controls,
            spacing=0,
        ),
    )

    content_holder.content = build_home()

    page.add(
        ft.Column(
            [
                ft.SafeArea(
                    content_holder,
                    expand=True,
                ),
                bottom_navigation,
            ],
            spacing=0,
            expand=True,
        )
    )

    def refresh_home():
        content_holder.content = build_home()
        bottom_navigation.selected_index = 0
        page.update()

    async def login_success(user):
        page.overlay.clear()
        await refresh_user_data()
        nav_containers["Admin"].visible = get_is_admin()
        refresh_home()

    if get_current_user() is None:
        auth_screen = build_auth_view(page, login_success)
        page.overlay.append(auth_screen)
        page.update()
    else:
        refresh_home()

    
ft.run(main)
