import hashlib
import json
from pathlib import Path
from statistics import mean

import compare_schedules as comparison
from repeat_experiments import (
    RUNS,
    METRICS,
    STRATEGIES,
    confidence_interval,
    save_csv,
)
from virtual_learners import create_virtual_learners


BASE = Path(__file__).resolve().parent

# Exploratory assumptions, not measured learner values.
# Each scenario changes one factor relative to baseline.
SCENARIOS = (
    ("baseline", 1.0, 1.25, 1.05),
    ("shorter_memory", 0.5, 1.25, 1.05),
    ("longer_memory", 1.5, 1.25, 1.05),
    ("smaller_review_effect", 1.0, 1.10, 1.02),
    ("larger_review_effect", 1.0, 1.40, 1.10),
)


def run_scenario(name, memory_scale, success_gain, failure_gain):
    original_half_lives = comparison.HALF_LIFE_DAYS
    original_success = comparison.SUCCESS_MULTIPLIER
    original_failure = comparison.FAILURE_MULTIPLIER

    results = []
    run_rows = []
    differences = {metric: [] for metric in METRICS}

    try:
        # Change settings only in this running process.
        comparison.HALF_LIFE_DAYS = {
            profile: value * memory_scale
            for profile, value in original_half_lives.items()
        }
        comparison.SUCCESS_MULTIPLIER = success_gain
        comparison.FAILURE_MULTIPLIER = failure_gain

        for run_id in range(1, RUNS + 1):
            cohort = []

            for index, template in enumerate(create_virtual_learners()):
                learner = dict(template)
                learner["learner_id"] = (
                    f'R{run_id:03d}_{template["learner_id"]}'
                )
                learner["random_seed"] = (
                    1000000 + run_id * 100 + index
                )

                # Same seeds across schedules and scenarios.
                for strategy in STRATEGIES:
                    row = comparison.simulate(learner, strategy)
                    row["scenario"] = name
                    row["run_id"] = run_id
                    row["random_seed"] = learner["random_seed"]
                    cohort.append(row)

            results.extend(cohort)
            summaries = {}

            for strategy in STRATEGIES:
                summary = comparison.summarise([
                    row for row in cohort
                    if row["strategy"] == strategy
                ])
                summaries[strategy] = summary
                run_rows.append({
                    "scenario": name,
                    "run_id": run_id,
                    "strategy": strategy,
                    **summary,
                })

            for metric in METRICS:
                differences[metric].append(
                    summaries["ai_budgeted"][metric]
                    - summaries["fixed"][metric]
                )

        overall = {
            strategy: comparison.summarise([
                row for row in results
                if row["strategy"] == strategy
            ])
            for strategy in STRATEGIES
        }

        by_profile = {
            profile: {
                strategy: comparison.summarise([
                    row for row in results
                    if row["strategy"] == strategy
                    and row["memory_profile"] == profile
                ])
                for strategy in STRATEGIES
            }
            for profile in ("weak", "medium", "strong")
        }

        report = {
            "name": name,
            "half_life_days": dict(comparison.HALF_LIFE_DAYS),
            "success_multiplier": success_gain,
            "failure_multiplier": failure_gain,
            "summary": overall,
            "by_profile": by_profile,
            "paired_differences": {
                metric: {
                    "mean_ai_minus_fixed": mean(values),
                    "bootstrap_95_percent_interval": (
                        confidence_interval(values)
                    ),
                }
                for metric, values in differences.items()
            },
        }
        return report, results, run_rows

    finally:
        comparison.HALF_LIFE_DAYS = original_half_lives
        comparison.SUCCESS_MULTIPLIER = original_success
        comparison.FAILURE_MULTIPLIER = original_failure


def main():
    reports = []
    all_results = []
    all_runs = []

    for scenario in SCENARIOS:
        report, results, run_rows = run_scenario(*scenario)
        reports.append(report)
        all_results.extend(results)
        all_runs.extend(run_rows)

        print(f'\n{report["name"]}')
        for strategy in STRATEGIES:
            summary = report["summary"][strategy]
            print(
                f'{strategy}: '
                f'recall={summary["mean_final_recall_probability"]:.1%}, '
                f'revisions={summary["mean_revisions"]:.2f}'
            )

    # Verify that baseline reproduces the earlier evaluation.
    previous = json.loads(
        (BASE / "repeated_simulation_report.json").read_text(
            encoding="utf-8"
        )
    )
    for strategy in STRATEGIES:
        for metric in METRICS:
            old = previous["summary"][strategy][metric]
            new = reports[0]["summary"][strategy][metric]
            if abs(old - new) > 1e-10:
                raise RuntimeError(
                    "Baseline differs from the earlier report. "
                    "Check model, code, seeds and settings."
                )

    files = (
        "sensitivity_analysis.py",
        "repeat_experiments.py",
        "compare_schedules.py",
        "adaptive_scheduler.py",
        "fixed_scheduler.py",
        "memory_simulator.py",
        "run_simulation.py",
        "virtual_learners.py",
        "simulation_ai_model.json",
    )

    output = {
        "purpose": "exploratory_simulation_sensitivity_analysis",
        "runs_per_scenario": RUNS,
        "learners_per_run": len(create_virtual_learners()),
        "total_days": comparison.TOTAL_DAYS,
        "maximum_revisions_per_learner": comparison.REVISION_BUDGET,
        "risk_limit": comparison.RISK_LIMIT,
        "budget_policy": "spread_remaining_budget",
        "model_retrained": False,
        "baseline_reproduced": True,
        "validated_on_real_learners": False,
        "scope": (
            "One-factor-at-a-time parameter changes within the same "
            "exponential memory model. Exploratory analysis; "
            "not evidence of real-learner effectiveness."
        ),
        "interval_scope": (
            "Simulation randomness within each scenario; "
            "excludes model and real-learner uncertainty."
        ),
        "scenarios": reports,
        "source_sha256": {
            name: hashlib.sha256((BASE / name).read_bytes()).hexdigest()
            for name in files
        },
    }

    save_csv("sensitivity_results.csv", all_results)
    save_csv("sensitivity_runs.csv", all_runs)
    (BASE / "sensitivity_report.json").write_text(
        json.dumps(output, indent=2, allow_nan=False),
        encoding="utf-8",
    )

    print("\nBaseline reproduced successfully.")
    print("Saved sensitivity CSV files and JSON report.")
    print("Assumed simulation only; no real-learner validation.")


if __name__ == "__main__":
    main()