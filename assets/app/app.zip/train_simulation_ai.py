import csv
import hashlib
import json
from pathlib import Path

from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    brier_score_loss,
    log_loss,
    roc_auc_score,
)
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler


BASE = Path(__file__).resolve().parent
SOURCE = BASE / "simulation_dataset.csv"
OUTPUT = BASE / "simulation_ai_model.json"

# Only observable history is used.
# Learner ID, memory profile and hidden memory strength are excluded.
FEATURES = [
    "days_since_review",
    "previous_attempt_count",
    "previous_successes",
    "previous_failures",
    "previous_success",
    "consecutive_successes",
    "previous_gap_days",
]


def get_xy(rows):
    x = [
        [float(row[name]) for name in FEATURES]
        for row in rows
    ]
    y = [int(row["recall_failure"]) for row in rows]
    return x, y


def evaluate(y, probabilities):
    predictions = [
        int(probability >= 0.5)
        for probability in probabilities
    ]

    return {
        "accuracy": float(accuracy_score(y, predictions)),
        "brier_score": float(brier_score_loss(y, probabilities)),
        "log_loss": float(log_loss(y, probabilities, labels=[0, 1])),
        "roc_auc": float(roc_auc_score(y, probabilities)),
    }


def main():
    with SOURCE.open(newline="", encoding="utf-8") as file:
        rows = list(csv.DictReader(file))

    groups = {
        split: [row for row in rows if row["split"] == split]
        for split in ("train", "validation", "test")
    }

    ids = {
        split: {row["learner_id"] for row in group}
        for split, group in groups.items()
    }

    if (
        ids["train"] & ids["validation"]
        or ids["train"] & ids["test"]
        or ids["validation"] & ids["test"]
    ):
        raise ValueError("Learners overlap between data splits.")

    x_train, y_train = get_xy(groups["train"])
    x_validation, y_validation = get_xy(groups["validation"])
    x_test, y_test = get_xy(groups["test"])

    best_model = None
    best_loss = float("inf")
    best_c = None

    for c_value in (0.1, 1.0, 10.0):
        model = make_pipeline(
            StandardScaler(),
            LogisticRegression(C=c_value, max_iter=2000),
        )
        model.fit(x_train, y_train)

        probabilities = model.predict_proba(x_validation)[:, 1]
        loss = log_loss(
            y_validation, probabilities, labels=[0, 1]
        )

        if loss < best_loss:
            best_model = model
            best_loss = float(loss)
            best_c = c_value

    test_probabilities = best_model.predict_proba(x_test)[:, 1]
    test_metrics = evaluate(y_test, test_probabilities)

    # Simple comparison: always predict the training failure rate.
    failure_rate = sum(y_train) / len(y_train)
    baseline_metrics = evaluate(
        y_test, [failure_rate] * len(y_test)
    )

    scaler = best_model.steps[0][1]
    classifier = best_model.steps[1][1]

    result = {
        "model_type": "logistic_regression",
        "purpose": "virtual_learner_simulation",
        "validated_on_real_learners": False,
        "features": FEATURES,
        "classes": classifier.classes_.tolist(),
        "mean": scaler.mean_.tolist(),
        "scale": scaler.scale_.tolist(),
        "coefficients": classifier.coef_[0].tolist(),
        "intercept": float(classifier.intercept_[0]),
        "selected_c": best_c,
        "validation_log_loss": best_loss,
        "training_examples": len(y_train),
        "test_examples": len(y_test),
        "split_method": "disjoint_virtual_learners",
        "test_metrics": test_metrics,
        "constant_baseline_metrics": baseline_metrics,
        "dataset_sha256": hashlib.sha256(
            SOURCE.read_bytes()
        ).hexdigest(),
    }

    OUTPUT.write_text(
        json.dumps(result, indent=2, allow_nan=False),
        encoding="utf-8",
    )

    print(f"Saved: {OUTPUT.name}")
    print(f"Training examples: {len(y_train)}")
    print(f"Test examples: {len(y_test)}")
    print(f"Selected C: {best_c}")

    for name, metrics in (
        ("AI", test_metrics),
        ("Constant baseline", baseline_metrics),
    ):
        print(f"\n{name}")
        for metric, value in metrics.items():
            print(f"{metric}: {value:.4f}")

    print("\nSynthetic-data evaluation only.")
    print("Adaptive schedule comparison is still pending.")


if __name__ == "__main__":
    main()