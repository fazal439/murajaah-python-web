import math

from virtual_learners import create_virtual_learners


# Assumed half-lives for the initial simulation.
# These values are not measured Quran learner data.
HALF_LIFE_DAYS = {
    "weak": 1.0,
    "medium": 3.0,
    "strong": 7.0,
}


def recall_probability(days_since_review, half_life_days):
    days = float(days_since_review)
    half_life = float(half_life_days)

    if not math.isfinite(days) or days < 0:
        raise ValueError("Days must be finite and non-negative.")

    if not math.isfinite(half_life) or half_life <= 0:
        raise ValueError("Half-life must be finite and positive.")

    return 2 ** (-days / half_life)


if __name__ == "__main__":
    learners = create_virtual_learners()

    for profile in ("weak", "medium", "strong"):
        learner = next(
            item for item in learners
            if item["memory_profile"] == profile
        )
        half_life = HALF_LIFE_DAYS[profile]

        print(f"\n{learner['learner_id']} - {profile}")

        for day in (0, 1, 3, 7):
            probability = recall_probability(day, half_life)
            print(
                f"Day {day}: simulated recall probability "
                f"{probability:.1%}"
            )

    print("\nAssumed simulation only. No AI trained yet.")