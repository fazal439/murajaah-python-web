
import json
import math
from collections import defaultdict
from datetime import datetime, timezone
from functools import lru_cache
from pathlib import Path


@lru_cache(maxsize=1)
def load_model():
    path = Path(__file__).resolve().parent / "ai_model_test.json"
    return json.loads(path.read_text(encoding="utf-8"))


def parse_time(value):
    result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if result.tzinfo is None:
        raise ValueError("Timestamp needs a timezone.")
    return result


def predict_score(model, features):
    score = float(model["intercept"])

    for index, name in enumerate(model["features"]):
        value = float(features[name])
        scale = float(model["scale"][index])

        if not math.isfinite(value) or scale <= 0:
            raise ValueError("Invalid model input.")

        scaled = (value - model["mean"][index]) / scale
        score += scaled * model["coefficients"][index]

    if not math.isfinite(score):
        raise ValueError("Invalid model score.")

    if score >= 0:
        return 1 / (1 + math.exp(-score))

    exp_score = math.exp(score)
    return exp_score / (1 + exp_score)


def get_ai_test_scores(attempts, user_id):
    now = datetime.now(timezone.utc)
    groups = defaultdict(list)

    for row in attempts:
        if str(row.get("user_id")) != str(user_id):
            continue

        if str(row.get("data_version")) != "2":
            continue

        try:
            completed = parse_time(row["completed_at"])
            key = (int(row["surah_number"]), int(row["ayah_number"]))
        except (KeyError, TypeError, ValueError):
            continue

        if completed <= now:
            groups[key].append((completed, row))

    if not groups:
        return []

    model = load_model()
    results = []

    for (surah, ayah), history in groups.items():
        completed, previous = max(
            history,
            key=lambda item: (item[0], str(item[1].get("id", ""))),
        )

        try:
            features = {
                "previous_mistakes": int(previous["mistakes"]),
                "previous_response_seconds": float(
                    previous["response_time_seconds"]
                ),
                "previous_audio_plays": int(previous["audio_plays"]),
                "previous_attempt_count": len(history),
                "days_since_review": round(
                    (now - completed).total_seconds() / 86400, 8
                ),
                "word_count": int(previous["word_count"]),
            }

            if not (
                model["gap_min_days"]
                <= features["days_since_review"]
                <= model["gap_max_days"]
            ):
                continue

            score = predict_score(model, features)
        except (KeyError, TypeError, ValueError, OverflowError):
            continue

        results.append({
            "surah_number": surah,
            "ayah_number": ayah,
            "score": score,
            "features": features,
        })

    return sorted(results, key=lambda row: row["score"], reverse=True)