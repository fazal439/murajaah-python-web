import json
from pathlib import Path

import flet as ft


BASE = Path(__file__).resolve().parent
ACTIVE_COLOR = "#63E6BE"
INACTIVE_COLOR = "#8FA3B8"
CARD_COLOR = "#10243E"

LABELS = {
    "baseline": "Original assumptions",
    "shorter_memory": "Shorter memory",
    "longer_memory": "Longer memory",
    "smaller_review_effect": "Smaller review effect",
    "larger_review_effect": "Larger review effect",
}


def build_sensitivity_card():
    try:
        report = json.loads(
            (BASE / "sensitivity_report.json").read_text(
                encoding="utf-8"
            )
        )

        def comparison_row(label, fixed_value, ai_value):
            return ft.Row(
                [
                    ft.Container(
                        expand=2,
                        content=ft.Text(
                            label, size=12, color=INACTIVE_COLOR
                        ),
                    ),
                    ft.Container(
                        expand=1,
                        content=ft.Text(
                            fixed_value, size=14, color=ACTIVE_COLOR
                        ),
                    ),
                    ft.Container(
                        expand=1,
                        content=ft.Text(
                            ai_value, size=14, color=ACTIVE_COLOR
                        ),
                    ),
                ],
                spacing=8,
            )

        controls = [
            ft.Text(
                "Memory Assumption Checks",
                size=22,
                weight=ft.FontWeight.BOLD,
                color=ACTIVE_COLOR,
            ),
            ft.Text(
                f'{len(report["scenarios"])} exploratory settings · '
                f'{report["runs_per_scenario"]} runs per setting · '
                f'{report["learners_per_run"]} virtual learners per run',
                size=12,
                color=INACTIVE_COLOR,
            ),
            ft.Text(
                "One memory factor changes at a time. "
                "The trained AI model stays the same.",
                size=12,
                color=INACTIVE_COLOR,
            ),
        ]

        for scenario in report["scenarios"]:
            fixed = scenario["summary"]["fixed"]
            ai = scenario["summary"]["ai_budgeted"]
            half_lives = scenario["half_life_days"]

            controls.extend([
                ft.Divider(),
                ft.Text(
                    LABELS.get(scenario["name"], scenario["name"]),
                    size=16,
                    weight=ft.FontWeight.BOLD,
                    color=ACTIVE_COLOR,
                ),
                ft.Text(
                    "Initial memory half-life in days: "
                    f'weak {half_lives["weak"]:g}, '
                    f'medium {half_lives["medium"]:g}, '
                    f'strong {half_lives["strong"]:g}',
                    size=12,
                    color=INACTIVE_COLOR,
                ),
                ft.Text(
                    "Memory half-life multiplier after review: "
                    f'success ×{scenario["success_multiplier"]:g}, '
                    f'failure with corrective feedback '
                    f'×{scenario["failure_multiplier"]:g}',
                    size=12,
                    color=INACTIVE_COLOR,
                ),
                comparison_row("Measure", "Fixed", "AI"),
                comparison_row(
                    "Mean final recall probability",
                    f'{fixed["mean_final_recall_probability"]:.1%}',
                    f'{ai["mean_final_recall_probability"]:.1%}',
                ),
                comparison_row(
                    "Final simulated success rate",
                    f'{fixed["final_success_rate"]:.1%}',
                    f'{ai["final_success_rate"]:.1%}',
                ),
                comparison_row(
                    "Mean revisions",
                    f'{fixed["mean_revisions"]:.2f}',
                    f'{ai["mean_revisions"]:.2f}',
                ),
            ])

        controls.extend([
            ft.Divider(),
            ft.Text(
                f'{report["total_days"]} days per run · '
                "one simulated ayah per learner · "
                "same maximum revision budget for both schedules",
                size=12,
                color=INACTIVE_COLOR,
            ),
            ft.Text(
                "These checks vary parameters within one exponential "
                "memory model. They do not test other memory models.",
                size=12,
                color=INACTIVE_COLOR,
            ),
            ft.Text(
                "Assumed simulation values · "
                "not validated on real Quran learners",
                size=12,
                color="#FFB86B",
            ),
        ])

    except (OSError, ValueError, KeyError, TypeError) as error:
        print("Sensitivity dashboard error:", error)
        controls = [
            ft.Text(
                "Memory assumption results unavailable.",
                color=INACTIVE_COLOR,
            )
        ]

    return ft.Container(
        padding=18,
        bgcolor=CARD_COLOR,
        border_radius=20,
        content=ft.Column(controls, spacing=12),
    )