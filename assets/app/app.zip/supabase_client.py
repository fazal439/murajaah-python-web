from pathlib import Path
from datetime import datetime, timedelta, timezone
import json
import re

from supabase import AsyncClient, acreate_client


def read_env_file():
    env_path = Path(__file__).parent / ".env"
    values = {}
    if not env_path.exists():
        return values
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        name, value = line.split("=", 1)
        values[name.strip()] = value.strip().strip('"').strip("'")
    return values


from public_config import (
    SUPABASE_URL as PUBLIC_SUPABASE_URL,
    SUPABASE_PUBLISHABLE_KEY as PUBLIC_SUPABASE_KEY,
)

environment = read_env_file()

SUPABASE_URL = (
    environment.get("SUPABASE_URL")
    or PUBLIC_SUPABASE_URL
)

SUPABASE_KEY = (
    environment.get("SUPABASE_PUBLISHABLE_KEY")
    or environment.get("SUPABASE_ANON_KEY")
    or PUBLIC_SUPABASE_KEY
)

if not SUPABASE_URL or not SUPABASE_KEY:
    raise ValueError(
        "Supabase URL or publishable key is missing."
    )


_supabase: AsyncClient | None = None
_current_user = None
_progress_cache = []
_quiz_attempts_cache = []
_weekly_leaderboard_cache = []
_badges_cache = []
_daily_challenge_cache = {}
_daily_bonus_xp = 0
_celebrations_cache = []
_is_admin_cache = False
_admin_reports_cache = []
_admin_database_overview_cache = []

BADGE_DEFINITIONS = [
    ("first_step", "First Step", "🌱"),
    ("xp_100", "100 XP", "⭐"),
    ("streak_3", "3-Day Streak", "🔥"),
    ("surah_master", "Surah Master", "📖"),
    ("xp_500", "500 XP Champion", "👑"),
]


def get_username():
    if not _current_user:
        return "Murajaah User"
    metadata = _current_user.user_metadata or {}
    return (
        metadata.get("full_name")
        or (_current_user.email or "Murajaah User").split("@", 1)[0]
    )


async def get_supabase() -> AsyncClient:
    global _supabase
    if _supabase is None:
        _supabase = await acreate_client(SUPABASE_URL, SUPABASE_KEY)
    return _supabase


async def sign_up_user(name, email, password):
    client = await get_supabase()
    return await client.auth.sign_up(
        {
            "email": email,
            "password": password,
            "options": {"data": {"full_name": name}},
        }
    )


async def sign_in_user(email, password):
    global _current_user
    client = await get_supabase()
    response = await client.auth.sign_in_with_password(
        {"email": email, "password": password}
    )
    await _finish_sign_in(response)
    return response


def normalize_student_code(student_code):
    code = re.sub(r"\s+", "", str(student_code or "")).upper()
    if not re.fullmatch(r"MUR-\d{4,}", code):
        raise ValueError("Invalid Student ID. Example: MUR-1001")
    return code


def student_login_email(student_code):
    code = normalize_student_code(student_code).lower()
    return f"{code}@students.murajaah.invalid"


async def sign_in_student(student_code, pin):
    if not re.fullmatch(r"\d{6}", str(pin or "")):
        raise ValueError("PIN must contain exactly 6 digits.")
    client = await get_supabase()
    response = await client.auth.sign_in_with_password(
        {
            "email": student_login_email(student_code),
            "password": str(pin),
        }
    )
    await _finish_sign_in(response)
    return response


async def _finish_sign_in(response):
    global _current_user
    client = await get_supabase()
    _current_user = response.user
    if _current_user:
        blocked_response = await (
            client.rpc("is_current_user_blocked").execute()
        )
        if bool(blocked_response.data):
            await client.auth.sign_out()
            _current_user = None
            raise PermissionError(
                "Your account access has been blocked by the administrator."
            )


def get_account_type():
    if not _current_user:
        return "guest"
    metadata = _current_user.user_metadata or {}
    return metadata.get("account_type") or "adult"


def get_student_code():
    if not _current_user:
        return ""
    metadata = _current_user.user_metadata or {}
    return metadata.get("student_code") or ""


async def sign_out_user():
    global _current_user, _progress_cache, _quiz_attempts_cache
    global _weekly_leaderboard_cache
    global _badges_cache
    global _daily_challenge_cache, _daily_bonus_xp
    global _celebrations_cache
    global _is_admin_cache, _admin_reports_cache
    global _admin_database_overview_cache
    client = await get_supabase()
    await client.auth.sign_out()
    _current_user = None
    _progress_cache = []
    _quiz_attempts_cache = []
    _weekly_leaderboard_cache = []
    _badges_cache = []
    _daily_challenge_cache = {}
    _daily_bonus_xp = 0
    _celebrations_cache = []
    _is_admin_cache = False
    _admin_reports_cache = []
    _admin_database_overview_cache = []


def get_current_user():
    return _current_user


def get_user_progress():
    return list(_progress_cache)


def get_user_quiz_attempts():
    return list(_quiz_attempts_cache)


def get_weekly_leaderboard():
    return list(_weekly_leaderboard_cache)


def get_user_badges():
    return list(_badges_cache)


def get_is_admin():
    return bool(_is_admin_cache)


def get_admin_reports():
    return list(_admin_reports_cache)


def get_admin_database_overview():
    return list(_admin_database_overview_cache)


async def admin_set_user_blocked(user_id, blocked):
    if not _is_admin_cache:
        raise PermissionError("Admin access required.")
    client = await get_supabase()
    response = await (
        client.rpc(
            "admin_set_user_blocked",
            {"p_user_id": user_id, "p_blocked": bool(blocked)},
        ).execute()
    )
    await refresh_user_data()
    return response


async def admin_delete_user(user_id):
    if not _is_admin_cache:
        raise PermissionError("Admin access required.")
    client = await get_supabase()
    response = await (
        client.rpc(
            "admin_delete_user",
            {"p_user_id": user_id},
        ).execute()
    )
    await refresh_user_data()
    return response


def _edge_function_data(response):
    data = getattr(response, "data", response)
    if isinstance(data, bytes):
        data = data.decode("utf-8")
    if isinstance(data, str):
        try:
            data = json.loads(data)
        except json.JSONDecodeError:
            return {"message": data}
    return data or {}


async def _invoke_student_admin(body):
    """Invoke the student admin function reliably in desktop and web builds."""
    client = await get_supabase()
    try:
        from pyodide.http import pyfetch
    except ImportError:
        response = await client.functions.invoke(
            "student-admin",
            invoke_options={"body": body},
        )
        return _edge_function_data(response)

    session = await client.auth.get_session()
    if not session or not session.access_token:
        raise PermissionError("Sign in as administrator first.")

    response = await pyfetch(
        f"{SUPABASE_URL}/functions/v1/student-admin",
        method="POST",
        headers={
            "Authorization": f"Bearer {session.access_token}",
            "apikey": SUPABASE_KEY,
            "Content-Type": "application/json",
        },
        body=json.dumps(body),
    )
    data = await response.json()
    if response.status >= 400:
        message = data.get("error") if isinstance(data, dict) else None
        raise RuntimeError(message or f"Student service failed ({response.status}).")
    return data or {}


async def admin_create_student(student_name, pin):
    if not _is_admin_cache:
        raise PermissionError("Admin access required.")
    name = str(student_name or "").strip()
    pin_text = str(pin or "")
    if len(name) < 2:
        raise ValueError("Enter the student's full name.")
    if not re.fullmatch(r"\d{6}", pin_text):
        raise ValueError("PIN must contain exactly 6 digits.")
    data = await _invoke_student_admin(
        {
            "action": "create_student",
            "student_name": name,
            "pin": pin_text,
        }
    )
    if isinstance(data, dict) and data.get("error"):
        raise RuntimeError(data["error"])
    await refresh_user_data()
    return data


async def admin_reset_student_pin(user_id, pin):
    if not _is_admin_cache:
        raise PermissionError("Admin access required.")
    pin_text = str(pin or "")
    if not re.fullmatch(r"\d{6}", pin_text):
        raise ValueError("PIN must contain exactly 6 digits.")
    data = await _invoke_student_admin(
        {
            "action": "reset_pin",
            "user_id": str(user_id),
            "pin": pin_text,
        }
    )
    if isinstance(data, dict) and data.get("error"):
        raise RuntimeError(data["error"])
    return data


async def get_admin_user_details(user_id):
    if not _is_admin_cache:
        raise PermissionError("Admin access required.")
    client = await get_supabase()
    response = await (
        client.rpc(
            "get_admin_user_details",
            {"p_user_id": user_id},
        ).execute()
    )
    return response.data or {}


async def get_admin_table_records(table_key, limit=100):
    if not _is_admin_cache:
        raise PermissionError("Admin access required.")
    client = await get_supabase()
    response = await (
        client.rpc(
            "get_admin_table_records",
            {"p_table_key": table_key, "p_limit": int(limit)},
        ).execute()
    )
    return response.data or []


def get_daily_challenge():
    return dict(_daily_challenge_cache)


def get_daily_bonus_xp():
    return int(_daily_bonus_xp)


def get_cached_total_xp():
    return (
        sum(int(item.get("points") or 0) for item in _progress_cache)
        + int(_daily_bonus_xp)
    )


def pop_celebrations():
    celebrations = list(_celebrations_cache)
    _celebrations_cache.clear()
    return celebrations


def reward_snapshot():
    return {
        "badges": {
            badge.get("badge_code")
            for badge in _badges_cache
        },
        "daily_complete": bool(_daily_challenge_cache.get("completed")),
        "level": get_cached_total_xp() // 100 + 1,
    }


def queue_new_rewards(before):
    after_badges = {
        badge.get("badge_code"): badge.get("badge_name")
        for badge in _badges_cache
    }
    for code, name in after_badges.items():
        if code not in before["badges"]:
            _celebrations_cache.append(
                f"Badge unlocked: {name}!"
            )

    if (
        not before["daily_complete"]
        and _daily_challenge_cache.get("completed")
    ):
        _celebrations_cache.append(
            "Daily Challenge completed! +50 bonus XP"
        )

    new_level = get_cached_total_xp() // 100 + 1
    if new_level > before["level"]:
        _celebrations_cache.append(
            f"Level Up! You reached Level {new_level}"
        )


def calculate_earned_badges(progress, attempts, bonus_xp=0):
    total_xp = (
        sum(int(item.get("points") or 0) for item in progress)
        + int(bonus_xp)
    )
    completed_surah = any(
        int(item.get("completed_ayahs") or 0)
        >= int(item.get("total_ayahs") or 1)
        for item in progress
    )

    activity_dates = set()
    for attempt in attempts:
        completed_at = attempt.get("completed_at")
        if completed_at:
            activity_dates.add(
                datetime.fromisoformat(
                    completed_at.replace("Z", "+00:00")
                ).date()
            )

    today = datetime.now(timezone.utc).date()
    streak_day = today if today in activity_dates else today - timedelta(days=1)
    streak = 0
    while streak_day in activity_dates:
        streak += 1
        streak_day -= timedelta(days=1)

    earned_codes = set()
    if attempts:
        earned_codes.add("first_step")
    if total_xp >= 100:
        earned_codes.add("xp_100")
    if streak >= 3:
        earned_codes.add("streak_3")
    if completed_surah:
        earned_codes.add("surah_master")
    if total_xp >= 500:
        earned_codes.add("xp_500")

    return [
        {
            "user_id": _current_user.id,
            "username": get_username(),
            "badge_code": code,
            "badge_name": name,
            "badge_icon": icon,
        }
        for code, name, icon in BADGE_DEFINITIONS
        if code in earned_codes
    ]


async def refresh_user_data():
    global _progress_cache, _quiz_attempts_cache
    global _weekly_leaderboard_cache
    global _badges_cache
    global _daily_challenge_cache, _daily_bonus_xp
    global _is_admin_cache, _admin_reports_cache
    global _admin_database_overview_cache
    if not _current_user:
        _progress_cache = []
        _quiz_attempts_cache = []
        _weekly_leaderboard_cache = []
        _badges_cache = []
        _daily_challenge_cache = {}
        _daily_bonus_xp = 0
        _is_admin_cache = False
        _admin_reports_cache = []
        _admin_database_overview_cache = []
        return

    client = await get_supabase()
    blocked_response = await (
        client.rpc("is_current_user_blocked").execute()
    )
    if bool(blocked_response.data):
        await sign_out_user()
        raise PermissionError(
            "Your account access has been blocked by the administrator."
        )
    progress_response = await (
        client.table("surah_progress")
        .select("*")
        .eq("user_id", _current_user.id)
        .execute()
    )
    attempts_response = await (
        client.table("quiz_attempts")
        .select("*")
        .eq("user_id", _current_user.id)
        .order("completed_at", desc=True)
        .execute()
    )
    leaderboard_response = await (
        client.table("weekly_leaderboard")
        .select("username,weekly_xp,completed_ayahs")
        .order("weekly_xp", desc=True)
        .limit(50)
        .execute()
    )
    _progress_cache = progress_response.data or []
    _quiz_attempts_cache = attempts_response.data or []
    _weekly_leaderboard_cache = leaderboard_response.data or []

    today = datetime.now(timezone.utc).date()
    today_ayahs = 0
    for attempt in _quiz_attempts_cache:
        completed_at = attempt.get("completed_at")
        if completed_at:
            attempt_date = datetime.fromisoformat(
                completed_at.replace("Z", "+00:00")
            ).date()
            if attempt_date == today:
                today_ayahs += 1

    challenge_complete = today_ayahs >= 3
    await (
        client.table("daily_challenges")
        .upsert(
            {
                "user_id": _current_user.id,
                "username": get_username(),
                "challenge_date": today.isoformat(),
                "target_count": 3,
                "progress_count": min(today_ayahs, 3),
                "completed": challenge_complete,
                "reward_xp": 50 if challenge_complete else 0,
            },
            on_conflict="user_id,challenge_date",
        )
        .execute()
    )
    daily_response = await (
        client.table("daily_challenges")
        .select("challenge_date,target_count,progress_count,completed,reward_xp")
        .eq("user_id", _current_user.id)
        .order("challenge_date", desc=True)
        .execute()
    )
    daily_rows = daily_response.data or []
    _daily_challenge_cache = daily_rows[0] if daily_rows else {}
    _daily_bonus_xp = sum(
        int(row.get("reward_xp") or 0)
        for row in daily_rows
        if row.get("completed")
    )

    earned_badges = calculate_earned_badges(
        _progress_cache,
        _quiz_attempts_cache,
        _daily_bonus_xp,
    )
    if earned_badges:
        await (
            client.table("user_badges")
            .upsert(earned_badges, on_conflict="user_id,badge_code")
            .execute()
        )

    badges_response = await (
        client.table("user_badges")
        .select("badge_code,badge_name,badge_icon,unlocked_at")
        .eq("user_id", _current_user.id)
        .execute()
    )
    _badges_cache = badges_response.data or []

    admin_response = await client.rpc("is_admin").execute()
    _is_admin_cache = bool(admin_response.data)
    if _is_admin_cache:
        reports_response = await (
            client.rpc("get_admin_user_reports").execute()
        )
        _admin_reports_cache = reports_response.data or []
        overview_response = await (
            client.rpc("get_admin_database_overview").execute()
        )
        _admin_database_overview_cache = overview_response.data or []
    else:
        _admin_reports_cache = []
        _admin_database_overview_cache = []


async def save_quiz_attempt(
    surah_number,
    ayah_number,
    points,
    mistakes,
    *,
    started_at=None,
    response_time_seconds=None,
    audio_plays=None,
    word_count=None,
    completed_at=None,
):
    if not _current_user:
        raise PermissionError("Please sign in before saving an attempt.")

    before_rewards = reward_snapshot()
    client = await get_supabase()

    payload = {
        "user_id": _current_user.id,
        "username": get_username(),
        "surah_number": int(surah_number),
        "ayah_number": int(ayah_number),
        "points": int(points),
        "mistakes": int(mistakes),
    }

    # Old callers can still save without the new measurements.
    has_measurements = all(
        value is not None
        for value in (
            started_at,
            response_time_seconds,
            audio_plays,
            word_count,
        )
    )

    if has_measurements:
        payload.update({
            "started_at": started_at,
            "response_time_seconds": float(response_time_seconds),
            "audio_plays": int(audio_plays),
            "word_count": int(word_count),
            "data_version": 2,

            # Audio-assisted practice is not an unaided recall test.
            "recall_success": (
                int(mistakes) == 0
                if int(audio_plays) == 0
                else None
            ),
        })

    if completed_at is not None:
        payload["completed_at"] = completed_at

    response = await (
        client.table("quiz_attempts")
        .insert(payload)
        .execute()
    )

    await refresh_user_data()
    queue_new_rewards(before_rewards)

    today = datetime.now(timezone.utc).date()
    today_attempts = sum(
        1
        for attempt in _quiz_attempts_cache
        if attempt.get("completed_at")
        and datetime.fromisoformat(
            attempt["completed_at"].replace("Z", "+00:00")
        ).date() == today
    )

    if today_attempts > 0 and today_attempts % 5 == 0:
        _celebrations_cache.append(
            f"Amazing! You completed {today_attempts} Ayahs today!"
        )

    return response


async def save_surah_progress(
    surah_number,
    completed_ayahs,
    total_ayahs,
    points,
    mistakes,
):
    if not _current_user:
        return None
    before_rewards = reward_snapshot()
    mastery = completed_ayahs / total_ayahs * 100 if total_ayahs else 0
    client = await get_supabase()
    response = await (
        client.table("surah_progress")
        .upsert(
            {
                "user_id": _current_user.id,
                "username": get_username(),
                "surah_number": surah_number,
                "completed_ayahs": completed_ayahs,
                "total_ayahs": total_ayahs,
                "points": points,
                "mistakes": mistakes,
                "mastery_percentage": round(mastery, 2),
            },
            on_conflict="user_id,surah_number",
        )
        .execute()
    )
    await refresh_user_data()
    queue_new_rewards(before_rewards)
    return response
