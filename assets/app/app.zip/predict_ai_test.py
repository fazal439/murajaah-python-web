import csv
import json
import math
from pathlib import Path

BASE = Path(__file__).resolve().parent


def predict_failure(model, row):
    score = model["intercept"]

    for index, name in enumerate(model["features"]):
        value = float(row[name])
        scaled = (
            (value - model["mean"][index])
            / model["scale"][index]
        )
        score += scaled * model["coefficients"][index]

    if score >= 0:
        return 1 / (1 + math.exp(-score))

    exp_score = math.exp(score)
    return exp_score / (1 + exp_score)


def main():
    model = json.loads(
        (BASE / "ai_model_test.json").read_text(encoding="utf-8")
    )

    with (BASE / "ai_dataset_test.csv").open(
        newline="", encoding="utf-8-sig"
    ) as file:
        rows = list(csv.DictReader(file))

    print("SOFTWARE TEST ONLY — training examples reused.")
    print("These scores are not validated forgetting risks.\n")
    print("Surah  Ayah  Actual failure  Model score")

    for row in rows:
        probability = predict_failure(model, row)
        print(
            f'{row["surah_number"]:>5}  '
            f'{row["ayah_number"]:>4}  '
            f'{row["next_attempt_failure"]:>14}  '
            f'{probability:>10.3f}'
        )


if __name__ == "__main__":
    main()