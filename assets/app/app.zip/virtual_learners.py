def create_virtual_learners():
    learners = []

    for profile in ("weak", "medium", "strong"):
        for _ in range(10):
            number = len(learners) + 1

            learners.append({
                "learner_id": f"V{number:03d}",
                "memory_profile": profile,
                "random_seed": 1000 + number,
                "data_source": "simulation",
            })

    return learners


if __name__ == "__main__":
    learners = create_virtual_learners()

    print(f"Virtual learners: {len(learners)}")

    for profile in ("weak", "medium", "strong"):
        count = sum(
            learner["memory_profile"] == profile
            for learner in learners
        )
        print(f"{profile}: {count}")

    print("Simulation setup only. No real student data.")