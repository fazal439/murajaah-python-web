# Research Method Record

## Study purpose
Design and evaluate an AI-assisted revision scheduling framework
using virtual learner simulation and learning analytics.

## Memory simulation
Recall probability follows:
p = 2 ** (-days_since_review / half_life_days)

Initial assumed half-lives:
- Weak: 1 day
- Medium: 3 days
- Strong: 7 days

Initial learner variation: uniform factor from 0.8 to 1.2.
After successful revision, half-life is multiplied by 1.25.
After failed revision with assumed corrective feedback,
half-life is multiplied by 1.05.

These parameter values are assumptions, not measurements
from Quran learners.

## AI development
300 virtual learners generate 6,000 examples:
- Training: 180 learners, 3,600 examples.
- Validation: 60 learners, 1,200 examples.
- Testing: 60 learners, 1,200 examples.

Learners do not overlap across these splits.
Inputs contain elapsed time and previous revision history.
Hidden memory strength and memory profile are excluded.

StandardScaler and logistic regression are fitted on training data.
C is selected from 0.1, 1.0 and 10.0 using validation log loss.
The selected model is evaluated on held-out test learners
against a constant training-failure-rate baseline.

## Single-ayah evaluation
Compare a fixed three-day interval with an AI budgeted schedule.
Both have a maximum of nine revisions over 30 days.
Actual revision counts may differ.
Budget constraints may override the AI risk-based interval.

Repeat 50 runs with 30 virtual learners per run.
Sensitivity analysis changes memory duration and review effects
one factor at a time while keeping the AI model unchanged.

## Multi-ayah evaluation
Each virtual learner starts with ten simulated ayahs learned
on day 0. Initial learning cost is excluded.

Compare:
- Simple: fixed round-robin rotation.
- AI: select the three items with highest predicted failure risk.

AI ties favour older reviews, then lower item IDs.
If any checked history input exceeds the supported ranges,
the policy falls back to oldest-first selection.
This experiment does not use a risk threshold.

Both schedules make three revisions daily on days 1–29:
87 revisions per learner per schedule.
All ten items are assessed on day 30 before further revision.

Repeat 50 runs with 30 learners per run: 1,500 virtual cases.
Paired schedules share initial conditions and random draws.
Each schedule then develops its own revision history.

## Outcomes and uncertainty
Primary multi-ayah outcome: mean final recall probability.
Additional measures: simulated final success rate,
mean daily recall probability and revision counts.

Compute AI-minus-baseline differences within each run.
Use 5,000 bootstrap resamples of the 50 run-level differences
to obtain percentile 95% intervals.

Intervals describe simulation randomness under the fixed
assumed memory model. They exclude memory-model uncertainty
and uncertainty about real learners.

## Current findings
Single-ayah AI used fewer revisions but had lower final recall
probability than the fixed schedule.

Multi-ayah results did not show clear evidence of improved
final recall probability over round-robin scheduling.
This does not establish equivalence between the schedules.

Prediction performance and scheduling effectiveness are
evaluated separately. Good prediction does not by itself
establish better scheduling.

## Scope and remaining work
Results apply to the stated simulation assumptions.
Synthetic item IDs represent ayahs; Quran-specific difficulty,
interference and review duration are not measured.

Real-learner effectiveness, engagement and educational benefit
have not been validated.

The memory equation is referenced to Settles and Meeder (2016),
Equation 1.
Chosen parameter values need documented justification.
Exploratory checks of two additional assumed memory curves
are complete. Justification of the chosen parameter values
and real-learner validation remain outstanding.

## Reproducibility
Saved records include source hashes, dataset hash, seeds,
CSV outputs, JSON reports, PNG/PDF figures and
requirements_research.txt.
## Memory equation reference
Settles, B., & Meeder, B. (2016).
A Trainable Spaced Repetition Model for Language Learning.
Proceedings of ACL, 1848–1858.
https://doi.org/10.18653/v1/P16-1174

Equation 1 provides the exponential half-life recall formula
used in this simulator.

Our AI predictor is logistic regression, not the paper's
half-life regression model. The chosen half-lives and review
multipliers are our simulation assumptions, not Quran-specific
values established by this paper.
## Exploratory alternative memory checks
Three assumed memory curves were evaluated using new seeds,
50 runs per curve and 30 virtual learners per run.
The AI model remained frozen. Both schedules used 87 revisions.

AI-minus-round-robin mean final recall probability:
- Exponential: -0.047 percentage points;
  95% simulation interval [-0.134, +0.040].
- Power-law shape 1: -0.228 percentage points;
  interval [-0.320, -0.136].
- Power-law shape 2: -0.168 percentage points;
  interval [-0.247, -0.092].

The exponential comparison did not show a clear difference.
Under both assumed power-law curves, AI had slightly lower
final recall probability.

These exploratory checks do not demonstrate AI superiority
or establish effectiveness for real Quran learners.
## Rationale for assumed parameters
Half-lives of 1, 3 and 7 days were chosen as illustrative
scenarios spanning faster and slower forgetting.
They are not estimates of actual Quran learner groups.

Review multipliers of 1.25 after success and 1.05 after failure
represent an assumed learning benefit, including corrective
feedback after failure. Their exact values are not empirically
validated.

Sensitivity checks examine shorter and longer memory and
smaller and larger review effects. Alternative curves share
the same half-life but differ in shape.

These checks explore dependence on assumptions; they do not
validate those assumptions. Conclusions therefore apply only
to the tested simulation settings.