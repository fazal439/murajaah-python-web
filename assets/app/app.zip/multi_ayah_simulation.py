import csv
import hashlib
import json
import random
from pathlib import Path
from statistics import mean

from adaptive_scheduler import predict_failure, MAX_GAP_DAYS
from memory_simulator import HALF_LIFE_DAYS, recall_probability
from run_simulation import SUCCESS_MULTIPLIER, FAILURE_MULTIPLIER
from virtual_learners import create_virtual_learners


BASE = Path(__file__).resolve().parent
TOTAL_DAYS = 30
AYAH_COUNT = 10
DAILY_BUDGET = 3
STRATEGIES = ("round_robin", "ai_risk")

# Training examples had 0 to 19 previous attempts.
MAX_HISTORY_ATTEMPTS = 19


def choose_items(observations, strategy, day, daily_budget):
    # Scheduling receives observable history only.
    # Hidden memory half-lives are not passed here.
    if strategy == "round_robin":
        count = len(observations)
        selected = [
            observations[((day - 1) * daily_budget + offset) % count]
            for offset in range(daily_budget)
        ]
        return selected, {}, "fixed_rotation"

    if strategy != "ai_risk":
        raise ValueError("Unknown scheduling strategy.")

    unsupported = any(
        not 1 <= day - item["last_review_day"] <= MAX_GAP_DAYS
        or item["history"]["previous_attempt_count"]
        > MAX_HISTORY_ATTEMPTS
        or item["history"]["previous_gap_days"] > MAX_GAP_DAYS
        for item in observations
    )

    if unsupported:
        # Use an observable oldest-first rule when any input is
        # outside the training ranges. Do not extrapolate the AI.
        selected = sorted(
            observations,
            key=lambda item: (
                item["last_review_day"],
                item["item_id"],
            ),
        )[:daily_budget]
        return selected, {}, "fallback_oldest_first"

    risks = {
        item["item_id"]: predict_failure(
            item["history"],
            day - item["last_review_day"],
        )
        for item in observations
    }

    selected = sorted(
        observations,
        key=lambda item: (
            -risks[item["item_id"]],
            item["last_review_day"],
            item["item_id"],
        ),
    )[:daily_budget]

    return selected, risks, "highest_predicted_risk"


def simulate_learner(
    learner,
    strategy,
    total_days=TOTAL_DAYS,
    ayah_count=AYAH_COUNT,
    daily_budget=DAILY_BUDGET,
    keep_trace=False,
):
    if total_days < 2 or not 1 <= daily_budget <= ayah_count:
        raise ValueError("Invalid simulation settings.")

    seed = int(learner["random_seed"])
    ability = random.Random(seed).uniform(0.8, 1.2)
    items = []

    for index in range(ayah_count):
        rng = random.Random(seed * 100 + index)

        # Synthetic item variation, not measured Quran difficulty.
        item_factor = rng.uniform(0.7, 1.3)
        half_life = (
            HALF_LIFE_DAYS[learner["memory_profile"]]
            * ability
            * item_factor
        )

        items.append({
            "item_id": index + 1,
            "half_life": half_life,
            "last_review_day": 0,
            "revision_days": [],
            "draws": {
                day: rng.random()
                for day in range(1, total_days + 1)
            },
            "history": {
                "previous_attempt_count": 0,
                "previous_successes": 0,
                "previous_failures": 0,
                "previous_success": -1,
                "consecutive_successes": 0,
                "previous_gap_days": 0,
            },
        })

    daily_probabilities = []
    trace = []
    fallback_days = 0
    final_probabilities = []
    final_successes = []

    for day in range(1, total_days + 1):
        probabilities = {
            item["item_id"]: recall_probability(
                day - item["last_review_day"],
                item["half_life"],
            )
            for item in items
        }

        # Measure all items before today's reviews.
        daily_probabilities.append(mean(probabilities.values()))

        # All items receive a final assessment before day-30 reviews.
        if day == total_days:
            final_probabilities = [
                probabilities[item["item_id"]]
                for item in items
            ]
            final_successes = [
                int(
                    item["draws"][day]
                    < probabilities[item["item_id"]]
                )
                for item in items
            ]
            break

        observations = [
            {
                "item_id": item["item_id"],
                "last_review_day": item["last_review_day"],
                "history": dict(item["history"]),
            }
            for item in items
        ]

        selected, risks, reason = choose_items(
            observations, strategy, day, daily_budget
        )
        selected_ids = [item["item_id"] for item in selected]

        if (
            len(selected_ids) != daily_budget
            or len(set(selected_ids)) != daily_budget
        ):
            raise RuntimeError("Daily review budget was not respected.")

        fallback_days += int(reason == "fallback_oldest_first")

        for item_id in selected_ids:
            item = items[item_id - 1]
            history = item["history"]
            gap = day - item["last_review_day"]
            success = (
                item["draws"][day] < probabilities[item_id]
            )

            if keep_trace:
                trace.append({
                    "learner_id": learner["learner_id"],
                    "strategy": strategy,
                    "day": day,
                    "simulated_ayah_id": item_id,
                    "gap_days": gap,
                    "previous_attempt_count": (
                        history["previous_attempt_count"]
                    ),
                    "predicted_failure_risk": risks.get(item_id),
                    "selection_reason": reason,
                    "simulated_success": int(success),
                    "data_source": "simulation",
                })

            item["revision_days"].append(day)
            history["previous_attempt_count"] += 1

            if success:
                history["previous_successes"] += 1
                history["consecutive_successes"] += 1
                item["half_life"] *= SUCCESS_MULTIPLIER
            else:
                history["previous_failures"] += 1
                history["consecutive_successes"] = 0
                item["half_life"] *= FAILURE_MULTIPLIER

            history["previous_success"] = int(success)
            history["previous_gap_days"] = gap
            item["last_review_day"] = day

    total_revisions = sum(
        len(item["revision_days"]) for item in items
    )
    expected = daily_budget * (total_days - 1)

    if total_revisions != expected:
        raise RuntimeError("Total revision counts are unequal.")

    result = {
        "learner_id": learner["learner_id"],
        "memory_profile": learner["memory_profile"],
        "random_seed": seed,
        "strategy": strategy,
        "total_revisions": total_revisions,
        "mean_final_recall_probability": mean(final_probabilities),
        "final_success_rate": mean(final_successes),
        "mean_daily_recall_probability": mean(daily_probabilities),
        "fallback_days": fallback_days,
        "data_source": "simulation",
    }

    ayah_results = [
        {
            "learner_id": learner["learner_id"],
            "memory_profile": learner["memory_profile"],
            "strategy": strategy,
            "simulated_ayah_id": item["item_id"],
            "revisions": len(item["revision_days"]),
            "revision_days": ",".join(
                map(str, item["revision_days"])
            ),
            "final_recall_probability": final_probabilities[index],
            "final_recall_success": final_successes[index],
            "data_source": "simulation",
        }
        for index, item in enumerate(items)
    ]

    return result, ayah_results, trace


def summarise_learners(rows):
    return {
        "learners": len(rows),
        "mean_total_revisions": mean(
            row["total_revisions"] for row in rows
        ),
        "mean_final_recall_probability": mean(
            row["mean_final_recall_probability"] for row in rows
        ),
        "final_success_rate": mean(
            row["final_success_rate"] for row in rows
        ),
        "mean_daily_recall_probability": mean(
            row["mean_daily_recall_probability"] for row in rows
        ),
        "mean_fallback_days": mean(
            row["fallback_days"] for row in rows
        ),
    }


def save_csv(filename, rows):
    with (BASE / filename).open(
        "w", newline="", encoding="utf-8"
    ) as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    results = []
    ayah_results = []
    traces = []

    for index, template in enumerate(create_virtual_learners()):
        learner = dict(template)
        learner["random_seed"] = 3000000 + index

        for strategy in STRATEGIES:
            result, ayahs, trace = simulate_learner(
                learner,
                strategy,
                keep_trace=index == 0,
            )
            results.append(result)
            ayah_results.extend(ayahs)
            traces.extend(trace)

    summaries = {
        strategy: summarise_learners([
            row for row in results
            if row["strategy"] == strategy
        ])
        for strategy in STRATEGIES
    }

    for strategy, summary in summaries.items():
        print(f"\n{strategy}")
        print(
            "Mean final recall probability: "
            f'{summary["mean_final_recall_probability"]:.1%}'
        )
        print(
            "Final simulated success rate: "
            f'{summary["final_success_rate"]:.1%}'
        )
        print(
            "Mean total revisions per learner: "
            f'{summary["mean_total_revisions"]:.0f}'
        )
        print(
            "Mean fallback days: "
            f'{summary["mean_fallback_days"]:.2f}'
        )

    files = (
        "multi_ayah_simulation.py",
        "adaptive_scheduler.py",
        "memory_simulator.py",
        "run_simulation.py",
        "virtual_learners.py",
        "simulation_ai_model.json",
    )

    report = {
        "purpose": "multi_ayah_simulation_prototype",
        "runs": 1,
        "total_days": TOTAL_DAYS,
        "simulated_ayahs_per_learner": AYAH_COUNT,
        "daily_revision_budget": DAILY_BUDGET,
        "revision_days": TOTAL_DAYS - 1,
        "revisions_per_learner_per_schedule": (
            DAILY_BUDGET * (TOTAL_DAYS - 1)
        ),
        "initial_learning": (
            "All simulated items initially learned on day 0; "
            "initial learning cost is excluded."
        ),
        "item_variation": "Assumed uniform half-life factor 0.7 to 1.3",
        "half_life_days": HALF_LIFE_DAYS,
        "success_multiplier": SUCCESS_MULTIPLIER,
        "failure_multiplier": FAILURE_MULTIPLIER,
        "baseline_policy": "Fixed round-robin rotation",
        "ai_policy": (
            "Highest predicted failure risk; oldest-first fallback "
            "when any history input exceeds training ranges."
        ),
        "risk_threshold_used": False,
        "model_retrained": False,
        "validated_on_real_learners": False,
        "scope": (
            "Synthetic item IDs represent ayahs; no measured "
            "Quran-specific difficulty, interference or review duration."
        ),
        "summary": summaries,
        "source_sha256": {
            name: hashlib.sha256((BASE / name).read_bytes()).hexdigest()
            for name in files
        },
    }

    save_csv("multi_ayah_learners.csv", results)
    save_csv("multi_ayah_results.csv", ayah_results)
    save_csv("multi_ayah_example_trace.csv", traces)

    (BASE / "multi_ayah_report.json").write_text(
        json.dumps(report, indent=2, allow_nan=False),
        encoding="utf-8",
    )

    print("\nEqual revision counts verified.")
    print("Saved multi-ayah CSV files and JSON report.")
    print("One simulation run only; repeated evaluation pending.")


if __name__ == "__main__":
    main()