import hashlib
import json
from pathlib import Path
from statistics import mean

from multi_ayah_simulation import (
    simulate_learner,
    summarise_learners,
    save_csv,
    STRATEGIES,
    TOTAL_DAYS,
    AYAH_COUNT,
    DAILY_BUDGET,
)
from memory_simulator import HALF_LIFE_DAYS
from run_simulation import SUCCESS_MULTIPLIER, FAILURE_MULTIPLIER
from repeat_experiments import confidence_interval
from virtual_learners import create_virtual_learners


BASE = Path(__file__).resolve().parent
RUNS = 50
METRICS = (
    "mean_final_recall_probability",
    "final_success_rate",
    "mean_daily_recall_probability",
    "mean_total_revisions",
)


def main():
    all_learners = []
    all_ayahs = []
    all_runs = []
    example_trace = []
    differences = {metric: [] for metric in METRICS}

    templates = create_virtual_learners()
    expected_revisions = DAILY_BUDGET * (TOTAL_DAYS - 1)

    for run_id in range(1, RUNS + 1):
        cohort = []

        for index, template in enumerate(templates):
            learner = dict(template)
            learner["learner_id"] = (
                f'R{run_id:03d}_{template["learner_id"]}'
            )
            learner["random_seed"] = (
                4000000 + run_id * 100 + index
            )
            paired_counts = []

            for strategy in STRATEGIES:
                result, ayahs, trace = simulate_learner(
                    learner,
                    strategy,
                    keep_trace=run_id == 1 and index == 0,
                )

                paired_counts.append(result["total_revisions"])
                result["run_id"] = run_id
                cohort.append(result)

                for row in ayahs:
                    row["run_id"] = run_id
                    row["random_seed"] = learner["random_seed"]
                all_ayahs.extend(ayahs)

                for row in trace:
                    row["run_id"] = run_id
                example_trace.extend(trace)

            if paired_counts != [expected_revisions] * len(STRATEGIES):
                raise RuntimeError("Paired revision counts differ.")

        all_learners.extend(cohort)
        summaries = {}

        for strategy in STRATEGIES:
            summary = summarise_learners([
                row for row in cohort
                if row["strategy"] == strategy
            ])
            summaries[strategy] = summary
            all_runs.append({
                "run_id": run_id,
                "strategy": strategy,
                **summary,
            })

        for metric in METRICS:
            differences[metric].append(
                summaries["ai_risk"][metric]
                - summaries["round_robin"][metric]
            )

        if run_id % 10 == 0:
            print(f"Completed {run_id}/{RUNS} runs", flush=True)

    overall = {
        strategy: summarise_learners([
            row for row in all_learners
            if row["strategy"] == strategy
        ])
        for strategy in STRATEGIES
    }

    by_profile = {
        profile: {
            strategy: summarise_learners([
                row for row in all_learners
                if row["strategy"] == strategy
                and row["memory_profile"] == profile
            ])
            for strategy in STRATEGIES
        }
        for profile in ("weak", "medium", "strong")
    }

    paired = {
        metric: {
            "mean_ai_minus_round_robin": mean(values),
            "bootstrap_95_percent_interval": confidence_interval(values),
        }
        for metric, values in differences.items()
    }

    files = (
        "repeat_multi_ayah.py",
        "multi_ayah_simulation.py",
        "repeat_experiments.py",
        "adaptive_scheduler.py",
        "memory_simulator.py",
        "run_simulation.py",
        "virtual_learners.py",
        "simulation_ai_model.json",
    )

    report = {
        "purpose": "repeated_multi_ayah_simulation",
        "runs": RUNS,
        "learners_per_run": len(templates),
        "virtual_learner_cases": RUNS * len(templates),
        "simulated_ayahs_per_learner": AYAH_COUNT,
        "total_days": TOTAL_DAYS,
        "daily_revision_budget": DAILY_BUDGET,
        "revision_days": TOTAL_DAYS - 1,
        "revisions_per_learner_per_schedule": expected_revisions,
        "equal_revision_counts_verified": True,
        "seed_rule": "4000000 + run_id * 100 + learner_index",
        "initial_learning": (
            "All items initially learned on day 0; "
            "initial learning cost excluded."
        ),
        "item_variation": "Assumed uniform half-life factor 0.7 to 1.3",
        "half_life_days": HALF_LIFE_DAYS,
        "success_multiplier": SUCCESS_MULTIPLIER,
        "failure_multiplier": FAILURE_MULTIPLIER,
        "baseline_policy": "Fixed round-robin rotation",
        "ai_policy": (
            "Highest predicted failure risk; oldest-first fallback "
            "when any history input exceeds training ranges."
        ),
        "primary_outcome": "mean_final_recall_probability",
        "risk_threshold_used": False,
        "model_retrained": False,
        "validated_on_real_learners": False,
        "summary": overall,
        "by_profile_exploratory": by_profile,
        "paired_differences": paired,
        "interval_scope": (
            "Paired run-level bootstrap intervals describe simulation "
            "randomness under one fixed assumed memory model. "
            "They exclude model and real-learner uncertainty."
        ),
        "scope": (
            "Synthetic item IDs represent ayahs. No measured "
            "Quran-specific difficulty or interference. "
            "Review counts are equal; review duration is not modelled."
        ),
        "source_sha256": {
            name: hashlib.sha256((BASE / name).read_bytes()).hexdigest()
            for name in files
        },
    }

    save_csv("repeated_multi_ayah_learners.csv", all_learners)
    save_csv("repeated_multi_ayah_results.csv", all_ayahs)
    save_csv("repeated_multi_ayah_runs.csv", all_runs)
    save_csv("repeated_multi_ayah_trace.csv", example_trace)

    (BASE / "repeated_multi_ayah_report.json").write_text(
        json.dumps(report, indent=2, allow_nan=False),
        encoding="utf-8",
    )

    for strategy, summary in overall.items():
        print(f"\n{strategy}")
        print(
            "Mean final recall probability: "
            f'{summary["mean_final_recall_probability"]:.2%}'
        )
        print(
            "Final simulated success rate: "
            f'{summary["final_success_rate"]:.2%}'
        )
        print(
            "Mean daily recall probability: "
            f'{summary["mean_daily_recall_probability"]:.2%}'
        )
        print(
            "Mean total revisions per learner: "
            f'{summary["mean_total_revisions"]:.0f}'
        )
        print(
            "Mean fallback days: "
            f'{summary["mean_fallback_days"]:.2f}'
        )

    result = paired["mean_final_recall_probability"]
    low, high = result["bootstrap_95_percent_interval"]

    print(
        "\nAI minus round-robin final recall probability: "
        f'{result["mean_ai_minus_round_robin"] * 100:+.3f} '
        "percentage points"
    )
    print(
        "95% simulation interval: "
        f"{low * 100:+.3f} to {high * 100:+.3f} percentage points"
    )
    print("\nEqual revision counts verified for every learner.")
    print("Saved repeated multi-ayah CSV files and JSON report.")
    print("Simulation only; no real-learner validation.")


if __name__ == "__main__":
    main()