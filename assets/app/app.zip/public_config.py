SUPABASE_URL = "https://colaylbpivwpweiepqko.supabase.co"
SUPABASE_PUBLISHABLE_KEY = "sb_publishable_FmvOovsdkPFxEdYtghyXSw_Bv2CTy-t"