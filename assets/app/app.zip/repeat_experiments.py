import csv
import hashlib
import json
import random
from pathlib import Path
from statistics import mean

from compare_schedules import (
    simulate,
    summarise,
    TOTAL_DAYS,
    REVISION_BUDGET,
)
from adaptive_scheduler import RISK_LIMIT
from virtual_learners import create_virtual_learners


BASE = Path(__file__).resolve().parent
RUNS = 50
BOOTSTRAP_SAMPLES = 5000
STRATEGIES = ("fixed", "ai_budgeted")
METRICS = (
    "mean_final_recall_probability",
    "final_success_rate",
    "mean_daily_recall_probability",
    "mean_revisions",
)


def confidence_interval(values):
    # Resample whole runs to estimate Monte Carlo uncertainty.
    rng = random.Random(20261012)
    samples = sorted(
        mean(rng.choices(values, k=len(values)))
        for _ in range(BOOTSTRAP_SAMPLES)
    )
    return [
        samples[int(0.025 * (len(samples) - 1))],
        samples[int(0.975 * (len(samples) - 1))],
    ]


def save_csv(filename, rows):
    with (BASE / filename).open(
        "w", newline="", encoding="utf-8"
    ) as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    all_results = []
    run_results = []
    differences = {metric: [] for metric in METRICS}

    for run_id in range(1, RUNS + 1):
        cohort = []

        for index, template in enumerate(create_virtual_learners()):
            learner = dict(template)
            learner["learner_id"] = (
                f'R{run_id:03d}_{template["learner_id"]}'
            )
            learner["random_seed"] = 1000000 + run_id * 100 + index

            # Both schedules use the same learner seed.
            for strategy in STRATEGIES:
                row = simulate(learner, strategy)
                row["run_id"] = run_id
                row["random_seed"] = learner["random_seed"]
                cohort.append(row)

        all_results.extend(cohort)
        summaries = {}

        for strategy in STRATEGIES:
            rows = [
                row for row in cohort
                if row["strategy"] == strategy
            ]
            summary = summarise(rows)
            summaries[strategy] = summary
            run_results.append({
                "run_id": run_id,
                "strategy": strategy,
                **summary,
            })

        for metric in METRICS:
            differences[metric].append(
                summaries["ai_budgeted"][metric]
                - summaries["fixed"][metric]
            )

    overall = {
        strategy: summarise([
            row for row in all_results
            if row["strategy"] == strategy
        ])
        for strategy in STRATEGIES
    }

    paired = {
        metric: {
            "mean_ai_minus_fixed": mean(values),
            "bootstrap_95_percent_interval": confidence_interval(values),
        }
        for metric, values in differences.items()
    }

    source_files = (
        "repeat_experiments.py",
        "compare_schedules.py",
        "adaptive_scheduler.py",
        "fixed_scheduler.py",
        "memory_simulator.py",
        "run_simulation.py",
        "virtual_learners.py",
        "simulation_ai_model.json",
    )

    report = {
        "purpose": "repeated_virtual_learner_simulation",
        "runs": RUNS,
        "learners_per_run": len(create_virtual_learners()),
        "total_days": TOTAL_DAYS,
        "maximum_revisions_per_learner": REVISION_BUDGET,
        "risk_limit": RISK_LIMIT,
        "budget_policy": "spread_remaining_budget",
        "seed_rule": "1000000 + run_id * 100 + learner_index",
        "model_retrained": False,
        "validated_on_real_learners": False,
        "summary": overall,
        "paired_differences": paired,
        "interval_scope": (
            "Monte Carlo uncertainty under one fixed assumed memory "
            "model; excludes model and real-learner uncertainty."
        ),
        "source_sha256": {
            name: hashlib.sha256((BASE / name).read_bytes()).hexdigest()
            for name in source_files
        },
    }

    save_csv("repeated_simulation_results.csv", all_results)
    save_csv("repeated_simulation_runs.csv", run_results)
    (BASE / "repeated_simulation_report.json").write_text(
        json.dumps(report, indent=2, allow_nan=False),
        encoding="utf-8",
    )

    print(f"Completed: {RUNS} simulation runs")

    for strategy, summary in overall.items():
        print(f"\n{strategy}")
        print(
            "Mean final recall probability: "
            f'{summary["mean_final_recall_probability"]:.1%}'
        )
        print(
            "Final simulated success rate: "
            f'{summary["final_success_rate"]:.1%}'
        )
        print(f'Mean revisions: {summary["mean_revisions"]:.2f}')

    print("\nSaved repeated simulation CSV files and JSON report.")
    print("Simulation only. No real-learner validation.")


if __name__ == "__main__":
    main()